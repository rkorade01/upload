﻿import { CopilotClient } from '@github/copilot-sdk';
const client = new CopilotClient();
try {
  const models = await client.listModels();
  console.log('Available models:');
  models.forEach(m => console.log(' -', JSON.stringify(m)));
} catch(e) {
  console.error('Error:', e.message);
} finally {
  await client.stop();
}
