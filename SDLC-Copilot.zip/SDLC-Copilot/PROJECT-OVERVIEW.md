# SDLC Copilot — Project Overview

> A plain-language guide for anyone who wants to understand what SDLC Copilot is, why it exists, and how it works — no coding knowledge required.

---

## What is SDLC Copilot?

SDLC Copilot is an **AI-powered assistant for software development teams**. It connects to your GitHub repositories and uses the power of large language models (like GPT or Claude) to help teams understand their code, answer project questions, and write better requirement documents — all in real time through a web browser.

Think of it as having a knowledgeable team member available 24/7 who has read all your project documentation and can answer questions, explain how things work, and help your analysts write clear requirement documents.

---

## The Three Things It Does

### 1. File Summarizer
**"What does this file do?"**

Give the assistant a GitHub repository address and a file path. Within seconds, it reads the file and explains it in plain English — whether the file is a complex piece of code, a configuration file, or a long markdown document.

```
You type:   facebook / react / packages/react/README.md
You get:    A structured summary explaining what the file contains,
            its purpose, key sections, and important notes.
```

---

### 2. Knowledge Base Chat
**"How does [feature/module/process] work?"**

Connect the assistant to your project's documentation repository (a GitHub repo containing your markdown files, guides, and notes). Once connected, you can ask it any question in plain English and it will:
- Search through the relevant documentation files
- Answer based only on your actual project docs (not guessing)
- Ask a clarifying question if your question is ambiguous
- Tell you honestly if the information isn't in the docs

```
You ask:    "How does the user authentication flow work?"
It answers: Reads the INDEX file, fetches auth-module.md from your 
            knowledge base, and gives a detailed, cited answer.
```

---

### 3. UD Creator (Understanding Document Creator)
**"Help me write a requirement document."**

This is the most powerful feature. A "UD" (Understanding Document) is a structured document that captures the full details of a software requirement before developers start building it. Creating a good UD normally takes a lot of back-and-forth between analysts and developers.

The UD Creator automates this process:

```
Step 1:  You describe a requirement (paste a ticket, write a few sentences)
Step 2:  The AI asks you 3–7 targeted clarifying questions
Step 3:  You answer; it may ask one more focused round if needed
Step 4:  It produces a complete UD draft, marking anything uncertain with ⚠️
Step 5:  You review and give feedback ("Change section 3", "Looks good")
Step 6:  It revises and shows what changed
Step 7:  You say "approved" — it generates a downloadable Markdown file
```

The AI uses your project's knowledge base during this process, so the UD it produces is tailored to your actual systems, naming conventions, and existing components.

---

## How It All Works — The Big Picture

```
                        ┌─────────────────────────────────────┐
                        │         Your Web Browser            │
                        │                                      │
                        │  ┌─────────────┐  ┌─────────────┐  │
                        │  │   KB Chat   │  │UD Creator   │  │
                        │  │  & Chat UI  │  │    UI       │  │
                        │  └──────┬──────┘  └──────┬──────┘  │
                        │         │                 │          │
                        │  ┌──────┴─────────────────┘          │
                        │  │   File Summarizer UI   │          │
                        │  └──────────┬─────────────┘          │
                        └────────────┼─────────────────────────┘
                                     │  Your request
                                     ▼
                        ┌─────────────────────────────────────┐
                        │          Application Server          │
                        │                                      │
                        │  • Checks who you are (API key)     │
                        │  • Limits request speed             │
                        │  • Manages your conversation        │
                        │  • Remembers what was said before   │
                        └──────────────┬──────────────────────┘
                                       │
                    ┌──────────────────┴──────────────────┐
                    │                                      │
                    ▼                                      ▼
      ┌─────────────────────────┐          ┌──────────────────────────┐
      │     Your GitHub Repo    │          │   GitHub Copilot AI      │
      │  (finds the file/doc)   │          │  (reads, thinks, replies)│
      └─────────────────────────┘          └──────────────────────────┘
                    │                                      │
                    └──────────────────────────────────────┘
                                       │
                                       ▼
                        ┌─────────────────────────────────────┐
                        │  Answer streams back to your screen  │
                        │  word by word, in real time          │
                        └─────────────────────────────────────┘
```

### In simple terms:

1. **You** type a question or paste a requirement into the web interface
2. **The server** receives it, verifies your identity, and routes it to the right AI workflow
3. **The AI** reads the relevant files from your GitHub documentation repo
4. **The answer** flows back to your screen word by word as it's being generated — no waiting for a complete response

---

## Key Concepts Explained Simply

### What is a "Session"?
When you open the chat, the system creates a private "session" for you. This session remembers everything you've said in that conversation — like a phone call that stays open. You can ask follow-up questions without repeating yourself. Sessions automatically close after 30 minutes of inactivity.

### What is the "Knowledge Base"?
The knowledge base is a GitHub repository containing your project's documentation — markdown files explaining how your systems work, what modules exist, API references, etc. The assistant reads an INDEX file to understand what topics live in which files, then fetches the right files when you ask a question.

### What is "Streaming"?
Instead of waiting for the AI to finish its entire response and then showing it all at once, SDLC Copilot displays the answer token by token as it's generated — you see text appearing live, like watching someone type. This means you get useful information faster.

### What is a "Tool"?
When the AI needs to look something up (like fetching a documentation file), it uses "tools" — predefined actions it can take. This is similar to a research assistant who knows they can look up information in the company wiki. The AI decides on its own when a tool call is needed.

### What is SSE?
SSE (Server-Sent Events) is the web technology that sends the streaming text from the server to your browser in real time. It is what makes answers appear word by word.

---

## Who Uses What Feature?

| Role | Primary Feature | How It Helps |
|---|---|---|
| **Business Analyst** | UD Creator | Creates thorough requirement documents with AI guidance |
| **Developer** | KB Chat + File Summarizer | Understands unfamiliar code and project components quickly |
| **Tech Lead / Architect** | KB Chat | Answers "how does X work?" questions for the team |
| **Product Manager** | KB Chat | Gets plain-English answers about system capabilities |
| **New Team Member** | KB Chat + File Summarizer | Onboards faster by exploring the codebase with AI guidance |
| **QA Engineer** | UD Creator + KB Chat | Understands requirements deeply and asks about edge cases |

---

## The UD Creation Process — Step by Step

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         UD Creator Workflow                              │
└─────────────────────────────────────────────────────────────────────────┘

   Analyst                    AI (UD Creator Mode)              Knowledge Base
      │                               │                               │
      │  Switch to "UD Creator"       │                               │
      ├──────────────────────────────►│                               │
      │                               │ Load project docs             │
      │                               ├──────────────────────────────►│
      │                               │◄──────────────────────────────┤
      │                               │                               │
      │  Paste requirement / ticket   │                               │
      ├──────────────────────────────►│                               │
      │                               │ Read relevant KB files        │
      │                               ├──────────────────────────────►│
      │                               │◄──────────────────────────────┤
      │                               │                               │
      │◄──────────────────────────────┤                               │
      │  Receives 3-7 questions       │                               │
      │  (Scope? Data? Logic? UI?)    │                               │
      │                               │                               │
      │  Answers questions            │                               │
      ├──────────────────────────────►│                               │
      │                               │  (May ask 1 more round        │
      │                               │   if still unclear)           │
      │◄──────────────────────────────┤                               │
      │  Receives complete UD draft   │                               │
      │  (⚠️ marks uncertain items)   │                               │
      │                               │                               │
      │  Reviews and gives feedback   │                               │
      ├──────────────────────────────►│                               │
      │◄──────────────────────────────┤                               │
      │  Revised UD with change notes │                               │
      │                               │                               │
      │  "Approved" / "Looks good"    │                               │
      ├──────────────────────────────►│                               │
      │                               │ Generates UD_TICKET-123.md    │
      │◄──────────────────────────────┤                               │
      │  Download link appears        │                               │
      │  in chat                      │                               │
```

### What the AI will ask about (the 7 question categories):

| Category | What the AI is asking | Example |
|---|---|---|
| **Scope** | What's in, what's out | "What exactly should this NOT affect?" |
| **Data / Mapping** | Where data comes from and goes | "Which system is the source? What field maps to what?" |
| **Business Logic** | Rules, conditions, edge cases | "What happens if the user has no account yet?" |
| **Integration** | External systems involved | "Which API does this call? How often?" |
| **UI / UX** | Screens, forms, flows | "Is this a new screen or changing an existing one?" |
| **Testing** | How to know it's working | "What does a successful test look like?" |
| **Dependencies** | What must exist first | "Does the database table already exist?" |

---

## What Makes It Reliable?

### Your Conversation Is Private
Each chat session is locked to your account. Other users cannot see or access your conversation even if they somehow knew your session ID.

### The AI Stays on Topic
The KB Chat and UD Creator modes only answer based on your actual project documentation. If the information isn't in your knowledge base, the AI says so — it does not make things up or guess.

### It Handles Slow Networks
The server sends regular "heartbeat" signals to keep streaming connections alive even through corporate proxies that would otherwise cut off slow connections.

### It Protects Against Overuse
Rate limits prevent any single user from overwhelming the system with too many requests. The server also caps the total number of active conversations.

---

## Setting It Up — What You Need

To run SDLC Copilot, your team needs:

1. **A GitHub account** with an active **GitHub Copilot subscription**
2. **A GitHub Personal Access Token** (PAT) — a secure credential that lets the app read your repositories
3. **A documentation repository** on GitHub containing your project's markdown files (for KB Chat / UD Creator)
4. **An `INDEX.md`** in that repo — a table of contents that maps topics to file paths. This helps the AI navigate your docs efficiently.
5. **Node.js 18+** installed on the server where you'll run the application

---

## Frequently Asked Questions

**Q: Does the AI read my code, or just documentation?**
The File Summarizer can read any file (code, config, markdown). The KB Chat and UD Creator only read files from your designated documentation repository, and only files with allowed extensions (markdown by default).

**Q: Can it access private repositories?**
Yes. You provide a GitHub Personal Access Token with `repo` scope, and the app uses it to authenticate with GitHub's API directly.

**Q: Is my conversation stored anywhere?**
Conversations are held in the server's memory for the duration of your session (up to 30 minutes of inactivity). They are not written to a database or file. Restarting the server clears all sessions.

**Q: What happens if the AI doesn't know the answer?**
For KB Chat and UD Creator, the AI will explicitly say the information is not available in the knowledge base rather than guessing. An INDEX.md file in your KB repo helps it locate obscure topics before giving up.

**Q: Can multiple people use it at the same time?**
Yes. Each user gets their own independent session. The system supports up to 500 concurrent sessions by default (configurable).

**Q: How do I update the knowledge base?**
Commit updated markdown files to your KB GitHub repository. The next new chat session will pick up the latest versions of core files. Files fetched on-demand from the knowledge base are cached for performance but the cache is cleared when the server restarts.

**Q: What is an Understanding Document (UD)?**
A UD is a structured document that captures a software requirement in enough detail for developers to implement it without ambiguity. It typically includes scope, business rules, data mappings, UI changes, integration points, and testing criteria. The UD Creator automates the process of gathering this information through targeted questions.

---

## Glossary

| Term | Plain English |
|---|---|
| **API** | A way for software programs to talk to each other |
| **GitHub** | A platform for storing and sharing code online |
| **Copilot SDK** | A software toolkit that connects to GitHub's AI |
| **SSE** | Technology that streams text to your browser in real time |
| **LLM** | Large Language Model — the AI that reads and generates text |
| **Session** | A private, remembered conversation between you and the AI |
| **Knowledge Base (KB)** | Your GitHub repo containing project documentation |
| **Tool call** | An action the AI takes automatically, like fetching a file |
| **UD** | Understanding Document — a structured software requirement specification |
| **Rate limit** | A cap on how many requests can be made in a given time window |
| **PAT** | Personal Access Token — a secure GitHub credential |
| **Monorepo** | A single code repository containing multiple related projects |
