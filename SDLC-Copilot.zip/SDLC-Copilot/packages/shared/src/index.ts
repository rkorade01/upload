/** Request to summarize a file from a GitHub repo */
export interface SummarizeRequest {
  /** GitHub repo owner (e.g., "facebook") */
  owner: string;
  /** GitHub repo name (e.g., "react") */
  repo: string;
  /** File path within the repo (e.g., "README.md") */
  filePath: string;
  /** Optional branch/ref (defaults to main) */
  ref?: string;
}

/** Response from the summarize endpoint */
export interface SummarizeResponse {
  success: boolean;
  /** The generated summary */
  summary?: string;
  /** Original file content */
  fileContent?: string;
  /** Repo and file metadata */
  metadata?: {
    owner: string;
    repo: string;
    filePath: string;
    ref: string;
  };
  /** Error message if failed */
  error?: string;
}

/** Streaming event types for SSE */
export type StreamEventType = "chunk" | "metadata" | "done" | "error";

export interface StreamEvent {
  type: StreamEventType;
  data: string;
}

// ─── Chat Types ────────────────────────────────────

/** Single chat message for display purposes */
export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

/**
 * Request to the chat endpoint.
 * Client generates a stable UUID sessionId on page load and sends it with every message.
 * Server maintains the actual SDK session in a Map keyed by sessionId.
 * Only the current message is sent — the SDK session retains conversation context server-side.
 */
export interface ChatRequest {
  sessionId: string;          // UUID generated on frontend page load
  message: string;            // Current user message only
  mode?: "chat" | "ud";      // Session mode (defaults to "chat")
}

/** Streaming event types for chat SSE */
export type ChatStreamEventType =
  | "chunk"         // Assistant text delta
  | "done"          // Stream complete
  | "error"         // Error occurred
  | "tool_start"    // Tool execution started
  | "tool_complete" // Tool execution completed
  | "status"        // Status message (e.g., KB loading)
  | "ud_file_ready"; // UD file ready for download (UD mode only)

export interface ChatStreamEvent {
  type: ChatStreamEventType;
  data: string;
}

// ─── UD Types (Phase 3) ────────────────────────────

/** Payload carried by a ud_file_ready SSE event */
export interface UDFilePayload {
  filename: string; // e.g., "UD_TICKET-123.md"
  content: string;  // Complete UD in Markdown format
}
