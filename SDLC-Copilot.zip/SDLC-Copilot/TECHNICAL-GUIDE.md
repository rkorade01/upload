# SDLC Copilot — Technical Guide

> Intended audience: developers building on, extending, or operating SDLC Copilot.

---

## Table of Contents

1. [Repository Layout](#repository-layout)
2. [Technology Choices](#technology-choices)
3. [Server Modules](#server-modules)
4. [Frontend Modules](#frontend-modules)
5. [Request Lifecycle — File Summarizer](#request-lifecycle--file-summarizer)
6. [Request Lifecycle — KB Chat Agent](#request-lifecycle--kb-chat-agent)
7. [Request Lifecycle — UD Creator](#request-lifecycle--ud-creator)
8. [Session Management](#session-management)
9. [Knowledge Base Service](#knowledge-base-service)
10. [Prompt System](#prompt-system)
11. [Authentication & Security Model](#authentication--security-model)
12. [Rate Limiting](#rate-limiting)
13. [SSE Streaming Protocol](#sse-streaming-protocol)
14. [Environment Variables Reference](#environment-variables-reference)
15. [Extension Points](#extension-points)
16. [Deployment Notes](#deployment-notes)

---

## Repository Layout

```
sdlc-copilot/                          Turborepo monorepo root
├── apps/
│   ├── web/                           Next.js 15 frontend
│   │   └── src/
│   │       ├── app/
│   │       │   ├── layout.tsx         Root layout, global CSS
│   │       │   └── page.tsx           Landing page — mounts ChatInterface + FileSummarizer
│   │       └── components/
│   │           ├── ChatInterface.tsx  KB Chat + UD Creator (dual-mode)
│   │           └── FileSummarizer.tsx File summarization UI
│   └── server/                        Express API server
│       └── src/
│           ├── index.ts               Server bootstrap, middleware wiring
│           ├── copilot.ts             CopilotClient singleton + warm-up
│           ├── chatAgent.ts           Session Map, tool definitions, getOrCreateSession()
│           ├── knowledgeBase.ts       KB startup loader, LRU fetch cache
│           ├── github.ts              GitHub REST API helper (summarizer)
│           ├── middleware/
│           │   ├── index.ts           Re-exports all middleware
│           │   ├── auth.ts            API key / Bearer token authentication
│           │   ├── rate-limit.ts      express-rate-limit configurations
│           │   └── validate.ts        Input validators, length limits
│           ├── routes/
│           │   ├── summarize.ts       POST /api/summarize[/stream]
│           │   └── chat.ts            POST /api/chat/stream, GET /api/chat/status
│           └── prompts/
│               ├── prompt-loader.ts   Assembles final system prompt strings
│               ├── system-prompt.md   KB Chat assistant persona template
│               ├── ud-system-prompt.md UD Analyst persona + workflow + UD template injection
│               └── ud-template.md     Standalone UD output template (injected into ud-system-prompt)
└── packages/
    └── shared/
        └── src/index.ts               Shared TypeScript interfaces used by both apps
```

---

## Technology Choices

| Concern | Choice | Reason |
|---|---|---|
| Monorepo | Turborepo + npm workspaces | Zero-config task pipeline, shared `node_modules` hoisting |
| Frontend | Next.js 15 (App Router) | SSR capable; `"use client"` for interactive chat components |
| Backend | Express 4 | Minimal, well-understood; easy SSE with `res.write()` |
| AI runtime | `@github/copilot-sdk` | Native Copilot session management, tool calling (`defineTool`), streaming, infinite sessions |
| LLM tool calling | Raw JSON schema (no Zod) | SDK's `defineTool` accepts `Record<string, unknown>` — no extra dependency needed |
| Session storage | In-process `Map` | Simple, zero-latency; suitable for single-instance deployments |
| File transport | GitHub REST API | Works for private repos via PAT; no MCP required |
| Security headers | Helmet | OWASP-recommended defaults |
| Auth | Custom HMAC-safe key check | `crypto.timingSafeEqual` prevents timing attacks |

---

## Server Modules

### `index.ts` — Server Bootstrap

Responsibilities:
- Loads `.env` from the monorepo root (two levels up from `apps/server/`)
- Mounts middleware in order: `helmet` → `cors` → `json` → `apiLimiter` → `authenticate` → routes
- Calls `warmUpCopilotClient()` and `initializeKnowledgeBase()` after the server starts listening
- Starts the **idle session reaper** (every 30 minutes)
- Handles `SIGINT` for graceful shutdown: destroys all sessions, stops Copilot client, closes HTTP server

```
SIGINT
  └─► destroyAllSessions()      closes all Copilot SDK sessions
  └─► stopCopilotClient()       tears down the client
  └─► server.close()            stops accepting new connections
```

### `copilot.ts` — Copilot SDK Client

- Holds a singleton `CopilotClient` instance
- Token resolution order: `COPILOT_TOKEN` → `COPILOT_GITHUB_TOKEN` → `GH_TOKEN` → SDK device-flow auth
- `warmUpCopilotClient()` calls `client.start()` and `client.listModels()` at startup — avoids cold-start latency on the first real request
- `getConfiguredModel()` normalizes model name aliases (e.g., `claude-sonnet-4.6` → `claude-sonnet-4-6`)

### `chatAgent.ts` — Session Manager

The most complex module. See [Session Management](#session-management) for details.

Key exports:
- `getOrCreateSession(clientSessionId, mode, userId)` — main entry point for the chat route
- `startSessionCleanup(idleMs)` — starts the periodic reaper
- `destroyAllSessions()` — used during graceful shutdown

### `knowledgeBase.ts` — KB Service

See [Knowledge Base Service](#knowledge-base-service).

### `github.ts` — GitHub File Fetcher (Summarizer)

Used only by the summarize route. Separate from `knowledgeBase.ts` so each can use a different token.

- `fetchFileContent({ owner, repo, filePath, ref })` → `string`
- Retries up to 2 times with exponential backoff (1 s, 2 s delays)
- Throws descriptive errors for 404, 401/403, and rate-limit (429) responses

### `middleware/auth.ts`

- Reads `API_KEYS` env var (comma-separated). If empty → dev mode, auth disabled (warning logged)
- Checks `x-api-key` header first, then `Authorization: Bearer <token>`
- Uses `crypto.timingSafeEqual` to prevent timing-based key enumeration
- Attaches `req.userId` as a SHA-256 hash (first 16 hex chars) of the validated key — never stores raw key

### `middleware/validate.ts`

- `validateChatRequest(body)` — checks sessionId is a valid UUID, message length ≤ 32 000 chars, mode is `"chat"` or `"ud"`
- `isValidUUID(v)` — strict UUID v4 regex
- All string path components validated against `SAFE_STRING_RE` (`/^[a-zA-Z0-9._\-/]+$/`)

### `routes/chat.ts`

- Applies `streamLimiter` per request
- Sets SSE headers (`Content-Type: text/event-stream`, `Cache-Control: no-cache`, `Connection: keep-alive`)
- Starts an SSE heartbeat (`": keepalive\n\n"`) on `SSE_HEARTBEAT_MS` interval to prevent proxy timeouts
- Registers per-request `session.on()` handlers; stores unsubscribe functions — all called on `res.close` to prevent event leaks on reused sessions
- Maps Copilot SDK events → SSE events:

| SDK event | SSE type | Notes |
|---|---|---|
| `assistant.message_delta` | `chunk` | Real-time token stream |
| `tool.execution_start` | `tool_start` | Also captures `create_ud_file` args for `ud_file_ready` |
| `tool.execution_complete` | `tool_complete` | Label from stored `toolCallLabels` map |
| `assistant.message_complete` | `done` | Ends the SSE stream |
| `error` | `error` | Ends the SSE stream |

---

## Frontend Modules

### `ChatInterface.tsx`

Dual-mode component: **KB Chat** and **UD Creator**.

State design:
- Two stable `useRef` session IDs — one per mode — generated with `crypto.randomUUID()` on mount. Never regenerated; surviving mode switches keeps both server sessions alive.
- Separate message arrays `chatMessages` / `udMessages` — switching mode preserves each conversation.
- Shared loading, error, and tool-activity state (reset on mode switch).

SSE consumption:
```
fetch(POST /api/chat/stream, body, headers)
  → ReadableStream via response.body.getReader()
  → TextDecoder processes chunks
  → JSON.parse({ type, data }) per line
  → dispatch by type: chunk | tool_start | tool_complete | ud_file_ready | done | error
```

UD file download:
- On `ud_file_ready`, creates a `Blob` from the content, calls `URL.createObjectURL`, stores URL in state + ref
- Blob URL is revoked on component unmount to prevent memory leaks

### `FileSummarizer.tsx`

Simpler: form → fetch → SSE reader → rendered Markdown. Includes a seconds-elapsed timer during streaming.

---

## Request Lifecycle — File Summarizer

```
Browser                     Express                      GitHub API       Copilot SDK
  │                             │                              │                │
  │  POST /api/summarize/stream │                              │                │
  │  { owner, repo, filePath }  │                              │                │
  ├────────────────────────────►│                              │                │
  │                             │  authenticate()              │                │
  │                             │  validateSummarizeRequest()  │                │
  │                             │                              │                │
  │                             │  fetchFileContent()          │                │
  │                             ├─────────────────────────────►│                │
  │                             │◄─────────────────────────────┤ raw file text  │
  │                             │                              │                │
  │                             │  getCopilotClient()          │                │
  │                             │  client.startSession(...)    │                │
  │                             │  session.send({ prompt })    │                │
  │                             ├──────────────────────────────────────────────►│
  │  SSE: chunk, chunk, ...     │                              │                │
  │◄────────────────────────────┤◄─────────────────────────────────────────────┤
  │  SSE: done                  │                              │                │
  │◄────────────────────────────┤                              │                │
```

---

## Request Lifecycle — KB Chat Agent

```
Browser                     Express                  knowledgeBase         Copilot SDK
  │                             │                         │                     │
  │  POST /api/chat/stream      │                         │                     │
  │  { sessionId, message,      │                         │                     │
  │    mode: "chat" }           │                         │                     │
  ├────────────────────────────►│                         │                     │
  │                             │  authenticate()         │                     │
  │                             │  validateChatRequest()  │                     │
  │                             │                         │                     │
  │                             │  getOrCreateSession()   │                     │
  │                             │  (lookup or create      │                     │
  │                             │   session in Map)       │                     │
  │                             │                         │                     │
  │  SSE: status "Processing"   │                         │                     │
  │◄────────────────────────────┤                         │                     │
  │                             │  session.send(message)  │                     │
  │                             ├────────────────────────────────────────────►  │
  │                             │                         │    LLM reasons...   │
  │                             │                         │                     │
  │                             │  ← tool call: fetch_kb_file("auth-module.md")│
  │                             │                         │                     │
  │  SSE: tool_start            │  fetchKBFileContent()   │                     │
  │◄────────────────────────────┤────────────────────────►│                     │
  │                             │                         │ GitHub REST GET     │
  │                             │                         │ (or LRU cache hit)  │
  │                             │◄────────────────────────┤ file content        │
  │                             │ tool result → SDK       │                     │
  │                             ├────────────────────────────────────────────►  │
  │  SSE: tool_complete         │                         │                     │
  │◄────────────────────────────┤                         │   LLM generates     │
  │  SSE: chunk, chunk, ...     │◄─────────────────────────────────────────────┤
  │◄────────────────────────────┤                         │                     │
  │  SSE: done                  │                         │                     │
  │◄────────────────────────────┤                         │                     │
```

---

## Request Lifecycle — UD Creator

```
Turns 1-N (questioning → drafting → revising)
  Same as KB Chat lifecycle above, but using mode="ud", different system prompt, and two tools.

Final turn (user says "approved")
  │
  ├── LLM calls create_ud_file({ filename, content })
  │
  ├── tool.execution_start handler in routes/chat.ts:
  │     - captures filename + content from args
  │     - emits SSE ud_file_ready { filename, content }
  │
  ├── Browser receives ud_file_ready:
  │     - new Blob([content], { type: "text/markdown" })
  │     - URL.createObjectURL(blob)
  │     - renders download link in chat
  │
  └── Tool handler returns "UD created successfully." to LLM
      LLM sends confirmation message → SSE chunks → done
```

---

## Session Management

### Composite Session Key

```
key = `${userId}:${clientSessionId}:${mode}`
```

- **`userId`** — SHA-256 hash of the validated API key (from `auth.ts`). Prevents session hijacking: even if a client guesses another UUID, they cannot access a session bound to a different user.
- **`clientSessionId`** — UUID generated by the browser on page load. Stable for the lifetime of the tab.
- **`mode`** — `"chat"` or `"ud"`. Separate sessions so each mode has its own system prompt and toolset.

### Session Creation

```typescript
// Enforces global and per-user caps before creating
if (sessions.size >= MAX_TOTAL_SESSIONS) → 503
if (userSessionCount >= MAX_SESSIONS_PER_USER) → 429

// Creates SDK session with:
client.startSession({
  model,
  systemMessage,          // assembled by prompt-loader.ts
  tools: [...],           // fetch_kb_file always; create_ud_file for "ud"
  streaming: true,
  infiniteSessions: { enabled: true },  // SDK handles context window compaction
  onPermissionRequest: approveAll,      // REQUIRED by SDK
})
```

### Idle Session Reaper

`startSessionCleanup(idleMs)` — runs on a `setInterval`. On each tick, iterates all sessions and destroys any where `Date.now() - lastUsedAt > idleMs`. Default idle threshold: 30 minutes.

Each `session.send()` call updates `lastUsedAt` in the session entry.

---

## Knowledge Base Service

### Initialization

At server startup, `initializeKnowledgeBase()`:
1. Reads `KB_REPO_OWNER`, `KB_REPO_NAME` from env. If missing → KB disabled (chat still works, but without KB context).
2. Fetches each file in `KB_CORE_FILES` (default: `INDEX.md`, `README.md`) from GitHub via REST.
3. Stores content in `knowledgeBase.coreContext` map.
4. Core context is injected into every new session's system prompt.

### On-Demand Fetching (LRU Cache)

```
fetch_kb_file("modules/payments.md")
  → check LRU cache (max 50 entries, LRU eviction)
  → cache miss → githubFetch(owner, repo, filePath, ref)
  → validate: extension in KB_FILE_EXTENSIONS, path matches SAFE_STRING_RE
  → store in cache → return content to LLM
```

### Token Resolution

```
KB_GITHUB_TOKEN → COPILOT_GITHUB_TOKEN → GH_TOKEN → GITHUB_TOKEN → (unauthenticated)
```

KB uses its own token chain so the KB repo can be a different org/account from the summarizer repo.

### Retry Logic

Up to 2 retries with exponential backoff (1 s, then 2 s). Surfaces meaningful errors for 404, 401/403, and 429 (rate limit with `Retry-After`).

---

## Prompt System

### How Prompts Are Assembled

`prompts/prompt-loader.ts` provides two assemblers:

**`loadSystemPrompt()`** (KB Chat mode):
```
Read system-prompt.md
Replace {{KB_PROJECT_NAME}} with KB_PROJECT_NAME env var
Replace {{CORE_CONTEXT}} with concatenated core KB files
```

**`loadUDSystemPrompt()`** (UD Creator mode):
```
Read ud-system-prompt.md
Read ud-template.md
Replace {{UD_TEMPLATE}} in ud-system-prompt.md with template content
Replace {{KB_PROJECT_NAME}} and {{CORE_CONTEXT}}
```

Prompts are assembled once per new session. Changing prompt `.md` files takes effect on the next session creation (no restart required).

### Prompt Responsibilities

| File | Role |
|---|---|
| `system-prompt.md` | Defines KB assistant persona, tool-use instructions, clarification rules, response formatting |
| `ud-system-prompt.md` | Defines UD Analyst role, 7-category questioning framework, 3-round limit, draft/revise/approve loop, `create_ud_file` gate |
| `ud-template.md` | UD output structure (injected into `ud-system-prompt.md` at `{{UD_TEMPLATE}}`) — edit this to change UD format |

---

## Authentication & Security Model

```
Client request
  │
  ├── Header: x-api-key: <key>
  │     → validateApiKey() using crypto.timingSafeEqual (timing-safe)
  │     → req.userId = sha256(key).slice(0, 16)
  │
  ├── Header: Authorization: Bearer <token>
  │     → same validation path
  │
  └── Neither header present
        → 401 Unauthorized

Dev mode (API_KEYS not set):
  → req.userId = "dev"
  → warning logged at startup
```

Key security properties:
- Raw API keys are never stored or logged; only hashed userId is used downstream
- `timingSafeEqual` prevents key enumeration via response time differences
- Session keys include `userId` — cross-user session access is structurally impossible

---

## Rate Limiting

Two `express-rate-limit` instances:

| Limiter | Applied to | Default |
|---|---|---|
| `apiLimiter` | All routes globally | 30 req / 60 s |
| `streamLimiter` | `POST /api/chat/stream` and `/api/summarize/stream` | 10 req / 60 s |

Configurable via env vars. Uses `standardHeaders: true` — returns `RateLimit-*` headers per RFC 6585.

---

## SSE Streaming Protocol

All streaming endpoints use the `text/event-stream` content type. Each event is a single JSON-encoded line:

```
data: {"type":"status","data":"Processing..."}\n\n
data: {"type":"chunk","data":"The authentication"}\n\n
data: {"type":"chunk","data":" module uses JWT"}\n\n
data: {"type":"tool_start","data":"Fetching auth-module.md…"}\n\n
data: {"type":"tool_complete","data":"auth-module.md loaded"}\n\n
data: {"type":"done","data":""}\n\n
```

UD-specific event:
```
data: {"type":"ud_file_ready","data":"{\"filename\":\"UD_TICK-123.md\",\"content\":\"# UD...\"}"}\n\n
```

Note: `ud_file_ready` `data` is a JSON-encoded string of a nested object. Parse twice:
```typescript
const outer = JSON.parse(line);        // { type: "ud_file_ready", data: "..." }
const payload = JSON.parse(outer.data); // { filename: "...", content: "..." }
```

Heartbeat comments keep connections alive:
```
: keepalive\n\n
```

---

## Environment Variables Reference

See the full configuration table in [README.md](README.md#configuration-env).

Additional developer notes:
- `COPILOT_MODEL` — run `node list-models.mjs` at the repo root to discover available models for your Copilot subscription
- `MAX_TOTAL_SESSIONS` / `MAX_SESSIONS_PER_USER` — tune based on your deployment's available RAM; each SDK session holds the full conversation context in memory

---

## Extension Points

### Adding a new agent mode

1. Create a new system prompt `.md` in `apps/server/src/prompts/`
2. Add a loader function in `prompt-loader.ts`
3. Add a new `mode` value to the `validateChatRequest` allowlist in `validate.ts`
4. Handle the new mode in `chatAgent.ts → getOrCreateSession()` — add a new `if (mode === "...")` branch

### Adding a new tool

In `chatAgent.ts`, call `defineTool(name, { description, parameters, handler })` and include it in the appropriate mode's tool array passed to `client.startSession()`.

The `handler` receives `args: unknown` — cast and validate as needed. Return a `string` that the LLM receives as the tool result.

### Replacing the in-process session Map

To support multi-instance deployments, replace the `Map` in `chatAgent.ts` with a Redis-backed store. The session value must implement the `CopilotSession` interface from the SDK. Note: SDK sessions are not serializable; you would need a Redis-managed session proxy or sticky routing.

### Changing the UD template

Edit `apps/server/src/prompts/ud-template.md`. The change takes effect on the next session creation.

---

## Deployment Notes

- The app is **stateful** (in-process `Map`). Run as a single instance unless you implement Redis-backed sessions with sticky routing.
- Set `API_KEYS` — auth is disabled in dev mode and will print a warning on startup
- The `NEXT_PUBLIC_API_KEY` is exposed in the browser bundle. Use only for internal/trusted deployments. For public-facing deployments, proxy API calls through a Next.js Route Handler that adds the key server-side.
- `/healthz` is intentionally unauthenticated and safe to expose to load balancer probes
- `KB_CORE_FILES` content is loaded once at startup. To refresh without restart, call `initializeKnowledgeBase()` again (expose an admin endpoint if needed)
