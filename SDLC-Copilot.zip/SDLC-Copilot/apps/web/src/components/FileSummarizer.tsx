"use client";

import { useState, useRef, useCallback, FormEvent } from "react";
import ReactMarkdown from "react-markdown";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
const API_KEY = process.env.NEXT_PUBLIC_API_KEY || "";

/** Standard headers for all API requests */
function apiHeaders(): Record<string, string> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (API_KEY) headers["x-api-key"] = API_KEY;
  return headers;
}

interface FormState {
  owner: string;
  repo: string;
  filePath: string;
  ref: string;
}

export function FileSummarizer() {
  const [form, setForm] = useState<FormState>({
    owner: "",
    repo: "",
    filePath: "",
    ref: "main",
  });
  const [summary, setSummary] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startTimer = useCallback(() => {
    setElapsed(0);
    timerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setSummary("");
    setLoading(true);
    startTimer();

    try {
      const res = await fetch(`${API_BASE}/api/summarize/stream`, {
        method: "POST",
        headers: apiHeaders(),
        body: JSON.stringify(form),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || `Server responded with ${res.status}`);
      }

      const reader = res.body?.getReader();
      if (!reader) throw new Error("No response body");

      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          let event;
          try {
            event = JSON.parse(line.slice(6));
          } catch {
            // ignore parse errors for non-JSON lines
            continue;
          }
          if (event.type === "chunk") {
            setSummary((prev) => prev + event.data);
          } else if (event.type === "error") {
            throw new Error(event.data);
          }
        }
      }
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
      stopTimer();
    }
  };

  const inputStyle: React.CSSProperties = {
    width: "100%",
    padding: "0.6rem 0.8rem",
    background: "var(--bg)",
    border: "1px solid var(--border)",
    borderRadius: "6px",
    color: "var(--text-primary)",
    fontSize: "0.95rem",
    outline: "none",
  };

  const labelStyle: React.CSSProperties = {
    display: "block",
    marginBottom: "0.25rem",
    fontSize: "0.85rem",
    color: "var(--text-secondary)",
    fontWeight: 500,
  };

  return (
    <div
      style={{
        width: "100%",
        maxWidth: "800px",
        background: "var(--bg-card)",
        border: "1px solid var(--border)",
        borderRadius: "12px",
        padding: "1.5rem",
      }}
    >
      {/* Form */}
      <form onSubmit={handleSubmit}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "1rem",
            marginBottom: "1rem",
          }}
        >
          <div>
            <label style={labelStyle}>Owner</label>
            <input
              style={inputStyle}
              placeholder="e.g. facebook"
              value={form.owner}
              onChange={(e) => setForm({ ...form, owner: e.target.value })}
              required
            />
          </div>
          <div>
            <label style={labelStyle}>Repository</label>
            <input
              style={inputStyle}
              placeholder="e.g. react"
              value={form.repo}
              onChange={(e) => setForm({ ...form, repo: e.target.value })}
              required
            />
          </div>
          <div>
            <label style={labelStyle}>File Path</label>
            <input
              style={inputStyle}
              placeholder="e.g. README.md"
              value={form.filePath}
              onChange={(e) => setForm({ ...form, filePath: e.target.value })}
              required
            />
          </div>
          <div>
            <label style={labelStyle}>Branch / Ref</label>
            <input
              style={inputStyle}
              placeholder="main"
              value={form.ref}
              onChange={(e) => setForm({ ...form, ref: e.target.value })}
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          style={{
            width: "100%",
            padding: "0.7rem",
            background: loading ? "var(--border)" : "var(--accent)",
            color: loading ? "var(--text-secondary)" : "#fff",
            border: "none",
            borderRadius: "8px",
            fontSize: "1rem",
            fontWeight: 600,
            cursor: loading ? "not-allowed" : "pointer",
            transition: "background 0.2s",
          }}
        >
          {loading ? `⏳ Summarizing... (${elapsed}s)` : "🔍 Fetch & Summarize"}
        </button>
      </form>

      {/* Error */}
      {error && (
        <div
          style={{
            marginTop: "1rem",
            padding: "0.75rem 1rem",
            background: "rgba(248, 81, 73, 0.1)",
            border: "1px solid var(--error)",
            borderRadius: "8px",
            color: "var(--error)",
            fontSize: "0.9rem",
          }}
        >
          ❌ {error}
        </div>
      )}

      {/* Summary output */}
      {summary && (
        <div
          className="markdown-content"
          style={{
            marginTop: "1.5rem",
            padding: "1.25rem",
            background: "var(--bg-secondary)",
            border: "1px solid var(--border)",
            borderRadius: "8px",
            maxHeight: "600px",
            overflowY: "auto",
          }}
        >
          <ReactMarkdown>{summary}</ReactMarkdown>
        </div>
      )}
    </div>
  );
}
