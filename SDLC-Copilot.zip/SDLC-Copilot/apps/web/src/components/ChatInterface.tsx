"use client";

import { useState, useRef, useEffect, useCallback, FormEvent } from "react";
import ReactMarkdown from "react-markdown";
import type { ChatMessage, ChatStreamEvent, UDFilePayload } from "@sdlc-copilot/shared";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
const API_KEY = process.env.NEXT_PUBLIC_API_KEY || "";

type Mode = "chat" | "ud";

/** Standard headers for all API requests */
function apiHeaders(): Record<string, string> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (API_KEY) headers["x-api-key"] = API_KEY;
  return headers;
}

interface DownloadInfo {
  filename: string;
  url: string;
}

function generateId(): string {
  // crypto.randomUUID is available in all modern browsers and Node 19+
  return crypto.randomUUID();
}

export function ChatInterface() {
  // ── Mode ────────────────────────────────────────────────────────────────────
  const [mode, setMode] = useState<Mode>("chat");

  // ── Per-mode stable session IDs (generated once on mount) ──────────────────
  const chatSessionId = useRef<string>(generateId());
  const udSessionId = useRef<string>(generateId());

  // ── Per-mode message histories ─────────────────────────────────────────────
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [udMessages, setUdMessages] = useState<ChatMessage[]>([]);

  // ── Shared UI state ────────────────────────────────────────────────────────
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [toolActivity, setToolActivity] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // ── UD download (latest approved UD file) ──────────────────────────────────
  const [udDownload, setUdDownload] = useState<DownloadInfo | null>(null);
  const udDownloadUrlRef = useRef<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Derived: active messages + setter for the current mode
  const messages = mode === "chat" ? chatMessages : udMessages;
  const setMessages = mode === "chat" ? setChatMessages : setUdMessages;
  const activeSessionId = mode === "chat" ? chatSessionId.current : udSessionId.current;

  // Auto-scroll to bottom when messages or tool activity change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages, udMessages, toolActivity]);

  // Revoke stale Blob URLs on unmount to avoid memory leaks
  useEffect(() => {
    return () => {
      if (udDownloadUrlRef.current) {
        URL.revokeObjectURL(udDownloadUrlRef.current);
      }
    };
  }, []);

  // ── Mode switch — clear transient UI state ─────────────────────────────────
  const switchMode = useCallback((newMode: Mode) => {
    setMode(newMode);
    setInput("");
    setError(null);
    setToolActivity(null);
    // Keep udDownload visible when switching modes so user doesn't lose the link
  }, []);

  // ── New Chat — reset session and messages for the active mode ─────────────
  const startNewSession = useCallback(() => {
    if (mode === "chat") {
      chatSessionId.current = generateId();
      setChatMessages([]);
    } else {
      udSessionId.current = generateId();
      setUdMessages([]);
      // Revoke stale blob URL
      if (udDownloadUrlRef.current) {
        URL.revokeObjectURL(udDownloadUrlRef.current);
        udDownloadUrlRef.current = null;
      }
      setUdDownload(null);
    }
    setInput("");
    setError(null);
    setToolActivity(null);
  }, [mode]);

  // ── Send message ───────────────────────────────────────────────────────────
  const sendMessage = useCallback(
    async (e?: FormEvent) => {
      e?.preventDefault();
      const text = input.trim();
      if (!text || isLoading) return;

      // Capture active mode state inside callback
      const currentMode = mode;
      const currentSessionId = currentMode === "chat" ? chatSessionId.current : udSessionId.current;
      const addMessage =
        currentMode === "chat"
          ? (msg: ChatMessage) => setChatMessages((prev) => [...prev, msg])
          : (msg: ChatMessage) => setUdMessages((prev) => [...prev, msg]);
      const updateLastAssistant =
        currentMode === "chat"
          ? (updater: (prev: ChatMessage[]) => ChatMessage[]) => setChatMessages(updater)
          : (updater: (prev: ChatMessage[]) => ChatMessage[]) => setUdMessages(updater);

      setInput("");
      setError(null);
      setToolActivity(null);

      // Optimistically add user message and assistant placeholder
      addMessage({ role: "user", content: text });
      addMessage({ role: "assistant", content: "" });
      setIsLoading(true);

      try {
        const res = await fetch(`${API_BASE}/api/chat/stream`, {
          method: "POST",
          headers: apiHeaders(),
          body: JSON.stringify({
            sessionId: currentSessionId,
            message: text,
            mode: currentMode,
          }),
        });

        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data.error || `Server responded with ${res.status}`);
        }

        const reader = res.body?.getReader();
        if (!reader) throw new Error("No response body");

        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            let event: ChatStreamEvent;
            try {
              event = JSON.parse(line.slice(6)) as ChatStreamEvent;
            } catch {
              continue;
            }

            switch (event.type) {
              case "chunk":
                // Append delta to the last (placeholder) assistant message
                updateLastAssistant((prev) => {
                  const updated = [...prev];
                  const last = updated[updated.length - 1];
                  if (last?.role === "assistant") {
                    updated[updated.length - 1] = {
                      ...last,
                      content: last.content + event.data,
                    };
                  }
                  return updated;
                });
                break;

              case "tool_start":
                setToolActivity(event.data);
                break;

              case "tool_complete":
                setToolActivity(null);
                break;

              case "ud_file_ready": {
                // Parse payload and create a Blob download URL
                const payload = JSON.parse(event.data) as UDFilePayload;
                if (udDownloadUrlRef.current) {
                  URL.revokeObjectURL(udDownloadUrlRef.current);
                }
                const blob = new Blob([payload.content], { type: "text/markdown" });
                const url = URL.createObjectURL(blob);
                udDownloadUrlRef.current = url;
                setUdDownload({ filename: payload.filename, url });
                break;
              }

              case "status":
                // Informational — ignore in UI
                break;

              case "done":
                setToolActivity(null);
                break;

              case "error":
                throw new Error(event.data);
            }
          }
        }
      } catch (err: any) {
        setError(err.message || "Something went wrong");
        // Remove empty assistant placeholder on error
        updateLastAssistant((prev) => {
          const last = prev[prev.length - 1];
          if (last?.role === "assistant" && last.content === "") {
            return prev.slice(0, -1);
          }
          return prev;
        });
      } finally {
        setIsLoading(false);
        setToolActivity(null);
        inputRef.current?.focus();
      }
    },
    [input, isLoading, mode]
  );

  // Submit on Enter (Shift+Enter = newline)
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const isChatMode = mode === "chat";
  const emptyHint = isChatMode
    ? "Ask me anything about this project."
    : "Paste or describe your requirement to start creating an Understanding Document.";
  const emptySubHint = isChatMode
    ? "I'll search the knowledge base and answer your questions."
    : "I'll ask clarifying questions, then draft a UD for your review.";
  const placeholder = isChatMode
    ? "Ask a question about this project... (Enter to send, Shift+Enter for newline)"
    : "Describe a requirement or paste a ticket description... (Enter to send)";

  return (
    <div className="chat-container">
      {/* Header */}
      <div className="chat-header">
        <span className="chat-header-icon" role="img" aria-label="copilot">
          🤖
        </span>
        <div className="chat-header-text">
          <h1 className="chat-header-title">SDLC Copilot</h1>
          <p className="chat-header-subtitle">
            {isChatMode ? "Knowledge Base Assistant" : "UD Creation Agent"}
          </p>
        </div>
        {/* Mode toggle */}
        <div className="chat-mode-toggle" role="group" aria-label="Switch mode">
          <button
            className={`chat-mode-btn ${isChatMode ? "chat-mode-btn--active" : ""}`}
            onClick={() => switchMode("chat")}
            disabled={isLoading}
            title="Knowledge Base Chat"
          >
            💬 KB Chat
          </button>
          <button
            className={`chat-mode-btn ${!isChatMode ? "chat-mode-btn--active" : ""}`}
            onClick={() => switchMode("ud")}
            disabled={isLoading}
            title="UD Creation Agent"
          >
            📄 UD Creator
          </button>
        </div>
        {/* New Chat button */}
        <button
          className="chat-new-btn"
          onClick={startNewSession}
          disabled={isLoading || messages.length === 0}
          title="Start a new conversation"
        >
          ✏️ New Chat
        </button>
      </div>

      {/* Message list */}
      <div className="chat-messages">
        {messages.length === 0 && (
          <div className="chat-empty">
            <p>{emptyHint}</p>
            <p className="chat-empty-hint">{emptySubHint}</p>
          </div>
        )}

        {messages.map((msg, i) => (
          <div
            key={i}
            className={`chat-bubble-wrapper ${
              msg.role === "user" ? "chat-bubble-wrapper--user" : "chat-bubble-wrapper--assistant"
            }`}
          >
            <div
              className={`chat-bubble ${
                msg.role === "user" ? "chat-bubble--user" : "chat-bubble--assistant"
              }`}
            >
              {msg.role === "assistant" ? (
                msg.content ? (
                  <div className="markdown-content">
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  </div>
                ) : (
                  <span className="chat-typing">● ● ●</span>
                )
              ) : (
                <span style={{ whiteSpace: "pre-wrap" }}>{msg.content}</span>
              )}
            </div>
          </div>
        ))}

        {/* Tool activity indicator */}
        {toolActivity && (
          <div className="chat-tool-activity">
            <span className="chat-tool-spinner" aria-hidden="true">⚙️</span>
            <span>{toolActivity}</span>
          </div>
        )}

        {/* UD download link — shown in UD mode after file is ready */}
        {!isChatMode && udDownload && (
          <div className="chat-ud-download">
            <span>📥</span>
            <span>Your UD is ready:</span>
            <a
              href={udDownload.url}
              download={udDownload.filename}
              className="chat-ud-download-link"
            >
              {udDownload.filename}
            </a>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="chat-error">
            <strong>Error:</strong> {error}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input area */}
      <form className="chat-input-form" onSubmit={sendMessage}>
        <textarea
          ref={inputRef}
          className="chat-input"
          placeholder={placeholder}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isLoading}
          rows={2}
        />
        <button
          type="submit"
          className={`chat-send-btn ${isLoading ? "chat-send-btn--loading" : ""}`}
          disabled={isLoading || !input.trim()}
        >
          {isLoading ? "⏳" : "➤"}
        </button>
      </form>
    </div>
  );
}
