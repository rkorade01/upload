import { ChatInterface } from "@/components/ChatInterface";

export default function HomePage() {
  return (
    <main
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "1rem",
      }}
    >
      <ChatInterface />
    </main>
  );
}
