import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SDLC Copilot — KB Assistant",
  description:
    "Knowledge base chat assistant powered by GitHub Copilot SDK",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
