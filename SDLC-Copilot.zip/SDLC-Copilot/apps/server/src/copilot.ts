/**
 * Copilot SDK wrapper
 * Manages the CopilotClient lifecycle and provides a helper
 * for chat completions.
 *
 * File fetching is done separately via GitHub REST API (see github.ts)
 * so that private repos work with a PAT. The Copilot SDK is used
 * purely for LLM summarization.
 */
import { CopilotClient } from "@github/copilot-sdk";

/** Model to use for summarization */
const DEFAULT_MODEL = "gpt-5";
const MODEL_ALIASES: Record<string, string> = {
  "claude-sonnet-4.6": "claude-sonnet-4-6",
};

export function getConfiguredModel(): string {
  const configured = (process.env.COPILOT_MODEL || DEFAULT_MODEL).trim();
  const normalized = MODEL_ALIASES[configured] || configured;

  if (normalized !== configured) {
    console.warn(`[copilot] Normalized model alias "${configured}" -> "${normalized}"`);
  }

  return normalized;
}

let clientInstance: CopilotClient | null = null;

/** Get or create the singleton CopilotClient */
export async function getCopilotClient(): Promise<CopilotClient> {
  if (!clientInstance) {
    console.time("[copilot] Client init");

    // The Copilot SDK needs a token with Copilot API access.
    // Keep this separate from GITHUB_TOKEN, which is also used for GitHub REST
    // fetches and may be a PAT without Copilot entitlement.
    // If no Copilot-specific token is set, the SDK falls back to the logged-in
    // user or device-flow auth.
    const token =
      process.env.COPILOT_TOKEN ||
      process.env.COPILOT_GITHUB_TOKEN ||
      process.env.GH_TOKEN;

    const options: Record<string, any> = {};
    if (token) {
      options.githubToken = token;
      console.log("[copilot] Using explicit token for auth");
    } else {
      console.log("[copilot] No Copilot-specific token set — SDK will use logged-in user / device flow");
    }

    clientInstance = new CopilotClient(options);
    console.timeEnd("[copilot] Client init");
  }
  return clientInstance;
}

/** Pre-warm the client so the first request isn't slow */
export async function warmUpCopilotClient(): Promise<void> {
  try {
    console.log("[copilot] Pre-warming client...");
    const client = await getCopilotClient();

    // Explicitly wait for the CLI connection to be established
    await client.start();
    console.log("[copilot] Client connected");

    // List available models so we know what's valid
    try {
      const models = await client.listModels();
      console.log("[copilot] Available models:", models.map((m: any) => m.id || m.name || m).join(", "));
    } catch (e) {
      console.warn("[copilot] Could not list models:", e);
    }
  } catch (err) {
    console.error("[copilot] Warm-up failed:", err);
  }
}

/** Stop the client (call on shutdown) */
export async function stopCopilotClient(): Promise<void> {
  if (clientInstance) {
    await clientInstance.stop();
    clientInstance = null;
  }
}

/**
 * Summarize pre-fetched file content using Copilot LLM.
 *
 * This does NOT use MCP / GitHub tools — the file content is already
 * fetched via the GitHub REST API (github.ts). We just ask the model
 * to analyze and summarize the provided text.
 */
export async function summarizeFileContent(params: {
  owner: string;
  repo: string;
  filePath: string;
  ref: string;
  fileContent: string;
  onChunk?: (chunk: string) => void;
}): Promise<string> {
  const { owner, repo, filePath, ref, fileContent, onChunk } = params;
  const model = getConfiguredModel();

  // Truncate very large files to keep LLM responses fast
  const MAX_CHARS = 30_000;
  let content = fileContent;
  let truncated = false;
  if (content.length > MAX_CHARS) {
    content = content.slice(0, MAX_CHARS);
    truncated = true;
    console.log(`[copilot] File truncated from ${fileContent.length} to ${MAX_CHARS} chars`);
  }
  console.log(`[copilot] Sending ${content.length} chars to LLM`);

  console.time("[copilot] getCopilotClient");
  const client = await getCopilotClient();
  console.timeEnd("[copilot] getCopilotClient");

  const systemPrompt = `You are a code analysis assistant. Your job is to analyze the provided file content and produce a clear, well-structured summary.

When summarizing, include:
- **Purpose**: What the file/code is for
- **Key Components**: Main classes, functions, exports, or sections
- **Dependencies**: Notable imports or external dependencies
- **Architecture Notes**: Design patterns, data flow, or important decisions
- **Notable Details**: Anything else worth highlighting

Format your response in clean Markdown.`;

  const useStreaming = !!onChunk;
  console.log(`[copilot] Using model: ${model}, streaming: ${useStreaming}`);
  console.time("[copilot] createSession");
  const session = await client.createSession({
    model,
    streaming: useStreaming,
    systemMessage: {
      mode: "replace",
      content: systemPrompt,
    },
    onPermissionRequest: async (request) => {
      console.warn("[copilot] Permission requested (auto-approving):", request.kind);
      return { kind: "approved" };
    },
    onUserInputRequest: async (request) => {
      console.warn("[copilot] User input requested (auto-responding):", request.question);
      return { answer: "", wasFreeform: true };
    },
  });
  console.timeEnd("[copilot] createSession");

  // Debug: log ALL session events to see what's happening
  session.on((event: any) => {
    if (event.type !== "pending_messages.modified") {
      console.log(`[copilot] Event: ${event.type}`, event.type === "session.error" ? event.data : "");
    }
  });

  const truncateNote = truncated ? `\n\n⚠️ Note: File was truncated to first ${MAX_CHARS} characters for analysis.` : "";

  const userPrompt = `Please analyze and summarize the following file.

**Repository:** \`${owner}/${repo}\` (branch: \`${ref}\`)
**File:** \`${filePath}\`${truncateNote}

---

\`\`\`
${content}
\`\`\`

---

Provide a detailed, well-structured summary of what this file does.`;

  let fullResponse = "";

  if (onChunk) {
    session.on("assistant.message_delta", (event: any) => {
      const delta = event.data.deltaContent;
      if (delta) {
        fullResponse += delta;
        onChunk(delta);
      }
    });
  }

  try {
    console.time("[copilot] sendAndWait");
    const response = await session.sendAndWait(
      { prompt: userPrompt },
      180_000 // 3-minute timeout
    );
    console.timeEnd("[copilot] sendAndWait");

    if (!onChunk && response?.data?.content) {
      fullResponse = response.data.content;
    }

    return fullResponse;
  } finally {
    await session.destroy();
  }
}
