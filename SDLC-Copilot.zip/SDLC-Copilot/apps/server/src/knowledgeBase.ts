/**
 * Knowledge Base service
 *
 * Loads core markdown files from a configurable GitHub repo at startup,
 * and provides on-demand fetching with LRU cache for additional files.
 *
 * Token resolution order: KB_GITHUB_TOKEN → COPILOT_GITHUB_TOKEN → GITHUB_TOKEN
 * This is intentionally separate from github.ts so KB can use a dedicated token.
 */

const GITHUB_API = "https://api.github.com";

// ─── Config ────────────────────────────────────────────────────────────────────

interface KBConfig {
  owner: string;
  name: string;
  ref: string;
  coreFiles: string[];
  allowedExtensions: string[];
  projectName: string;
  maxCacheSize: number;
}

function loadConfig(): KBConfig | null {
  const owner = process.env.KB_REPO_OWNER;
  const name = process.env.KB_REPO_NAME;

  if (!owner || !name) {
    console.warn("[KB] KB_REPO_OWNER / KB_REPO_NAME not set — knowledge base disabled");
    return null;
  }

  return {
    owner,
    name,
    ref: process.env.KB_REPO_REF || "main",
    coreFiles: (process.env.KB_CORE_FILES || "INDEX.md,README.md")
      .split(",")
      .map((f) => f.trim())
      .filter(Boolean),
    allowedExtensions: (process.env.KB_FILE_EXTENSIONS || ".md")
      .split(",")
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean),
    projectName: process.env.KB_PROJECT_NAME || "the project",
    maxCacheSize: 50,
  };
}

// ─── GitHub fetch (own impl — supports KB_GITHUB_TOKEN) ────────────────────────

function getKBToken(): string | null {
  return (
    process.env.KB_GITHUB_TOKEN ||
    process.env.COPILOT_GITHUB_TOKEN ||
    process.env.GH_TOKEN ||
    process.env.GITHUB_TOKEN ||
    null
  );
}

async function githubFetch(
  owner: string,
  repo: string,
  filePath: string,
  ref: string
): Promise<string> {
  const token = getKBToken();
  const url = `${GITHUB_API}/repos/${owner}/${repo}/contents/${filePath}?ref=${ref}`;

  const headers: Record<string, string> = {
    Accept: "application/vnd.github.v3+json",
    "User-Agent": "SDLC-Copilot-KB",
  };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  // Retry with exponential backoff (up to 2 retries for transient failures)
  const MAX_RETRIES = 2;
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    if (attempt > 0) {
      const delay = Math.min(1000 * 2 ** (attempt - 1), 4000);
      console.log(`[KB] Retry ${attempt}/${MAX_RETRIES} for ${filePath} after ${delay}ms`);
      await new Promise((r) => setTimeout(r, delay));
    }

    try {
      const res = await fetch(url, { headers });

      if (!res.ok) {
        const body = await res.text().catch(() => "");
        if (res.status === 404) {
          throw new Error(`KB file not found: ${filePath} in ${owner}/${repo}@${ref}`);
        }
        if (res.status === 401 || res.status === 403) {
          throw new Error(
            `KB access denied for ${owner}/${repo}. Check your KB_GITHUB_TOKEN or GITHUB_TOKEN. (HTTP ${res.status})`
          );
        }
        // Retry on 5xx
        if (res.status >= 500 && attempt < MAX_RETRIES) {
          lastError = new Error(`GitHub API error ${res.status} for ${filePath}: ${body.slice(0, 200)}`);
          continue;
        }
        throw new Error(`GitHub API error ${res.status} for ${filePath}: ${body.slice(0, 200)}`);
      }

      const data = (await res.json()) as any;

      if (data.encoding === "base64" && data.content) {
        return Buffer.from(data.content, "base64").toString("utf-8");
      }

      if (data.download_url) {
        const rawRes = await fetch(data.download_url, { headers });
        if (!rawRes.ok) {
          throw new Error(`Failed to download KB file from ${data.download_url}`);
        }
        return rawRes.text();
      }

      throw new Error(`Unexpected GitHub response for ${filePath}: no content or download_url`);
    } catch (err: any) {
      // Don't retry on non-transient errors (4xx, validation errors)
      if (err.message?.includes("not found") || err.message?.includes("access denied")) {
        throw err;
      }
      lastError = err;
      if (attempt >= MAX_RETRIES) throw err;
    }
  }

  throw lastError || new Error(`Failed to fetch ${filePath} after ${MAX_RETRIES + 1} attempts`);
}

// ─── LRU Cache ─────────────────────────────────────────────────────────────────

class LRUCache<K, V> {
  private maxSize: number;
  private cache: Map<K, V>;

  constructor(maxSize: number) {
    this.maxSize = maxSize;
    this.cache = new Map();
  }

  get(key: K): V | undefined {
    if (!this.cache.has(key)) return undefined;
    // Move to end (most recently used)
    const value = this.cache.get(key)!;
    this.cache.delete(key);
    this.cache.set(key, value);
    return value;
  }

  set(key: K, value: V): void {
    if (this.cache.has(key)) {
      this.cache.delete(key);
    } else if (this.cache.size >= this.maxSize) {
      // Remove oldest entry (first key)
      const oldest = this.cache.keys().next().value;
      if (oldest !== undefined) this.cache.delete(oldest);
    }
    this.cache.set(key, value);
  }

  has(key: K): boolean {
    return this.cache.has(key);
  }

  get size(): number {
    return this.cache.size;
  }
}

// ─── Knowledge Base Service ────────────────────────────────────────────────────

interface KBStatus {
  ready: boolean;
  filesLoaded: string[];
  errors: string[];
  cacheSize: number;
}

class KnowledgeBaseService {
  private config: KBConfig | null = null;
  private coreFiles: Map<string, string> = new Map();
  private fileCache: LRUCache<string, string> = new LRUCache(50);
  private errors: string[] = [];
  private ready = false;
  /** In-flight fetch promises for request coalescing */
  private inflight: Map<string, Promise<string>> = new Map();

  /**
   * Initialize the KB service: load core files from GitHub.
   * Called once at server startup.
   * Graceful partial loading — if one core file fails, others still load.
   */
  async initialize(): Promise<void> {
    this.config = loadConfig();
    if (!this.config) {
      console.log("[KB] Knowledge base disabled (no KB_REPO_OWNER/KB_REPO_NAME)");
      return;
    }

    const { owner, name, ref, coreFiles, maxCacheSize } = this.config;
    this.fileCache = new LRUCache(maxCacheSize);

    console.log(`[KB] Loading ${coreFiles.length} core files from ${owner}/${name}@${ref}...`);

    const results = await Promise.allSettled(
      coreFiles.map(async (filePath) => {
        const content = await githubFetch(owner, name, filePath, ref);
        this.coreFiles.set(filePath, content);
        console.log(`[KB] ✓ Loaded ${filePath} (${content.length} chars)`);
        return filePath;
      })
    );

    for (const result of results) {
      if (result.status === "rejected") {
        const msg = result.reason?.message || String(result.reason);
        console.error(`[KB] ✗ Failed to load core file: ${msg}`);
        this.errors.push(msg);
      }
    }

    const loaded = this.coreFiles.size;
    console.log(`[KB] Initialized: ${loaded}/${coreFiles.length} core files loaded`);
    this.ready = loaded > 0 || coreFiles.length === 0;
  }

  /**
   * Returns formatted core file contents for injection into the system prompt.
   */
  getCoreContext(): string {
    if (this.coreFiles.size === 0) {
      return "(No core knowledge base files loaded)";
    }

    const sections: string[] = [];
    for (const [filePath, content] of this.coreFiles.entries()) {
      sections.push(`### ${filePath}\n\n${content}`);
    }
    return sections.join("\n\n---\n\n");
  }

  /**
   * Fetch a KB file on-demand (with LRU caching).
   * Used by the fetch_kb_file tool handler.
   * Validates file extension against the whitelist.
   */
  async fetchKBFileContent(filePath: string): Promise<string> {
    if (!this.config) {
      throw new Error("Knowledge base is not configured (KB_REPO_OWNER / KB_REPO_NAME not set)");
    }

    // Normalize: strip leading slashes
    const normalized = filePath.replace(/^\/+/, "");

    // Guard against path traversal (e.g. "../../secret.md")
    if (normalized.includes("..")) {
      throw new Error(`Path traversal detected in filePath: "${filePath}"`);
    }

    // Validate extension
    const ext = "." + normalized.split(".").pop()?.toLowerCase();
    if (!this.config.allowedExtensions.includes(ext)) {
      throw new Error(
        `File extension "${ext}" is not allowed. Permitted extensions: ${this.config.allowedExtensions.join(", ")}`
      );
    }

    // Check LRU cache
    const cached = this.fileCache.get(normalized);
    if (cached !== undefined) {
      console.log(`[KB] Cache hit: ${normalized}`);
      return cached;
    }

    // Check if it's already a loaded core file
    const coreContent = this.coreFiles.get(normalized);
    if (coreContent !== undefined) {
      return coreContent;
    }

    // Request coalescing — if another request is already fetching this file, share it
    const existing = this.inflight.get(normalized);
    if (existing) {
      console.log(`[KB] Coalescing request for: ${normalized}`);
      return existing;
    }

    // Fetch from GitHub
    console.log(`[KB] Fetching on-demand: ${normalized}`);
    const { owner, name, ref } = this.config;

    const fetchPromise = githubFetch(owner, name, normalized, ref)
      .then((content) => {
        // Cache result
        this.fileCache.set(normalized, content);
        console.log(`[KB] Cached: ${normalized} (${content.length} chars)`);
        return content;
      })
      .finally(() => {
        this.inflight.delete(normalized);
      });

    this.inflight.set(normalized, fetchPromise);
    return fetchPromise;
  }

  /**
   * Returns the KB service status.
   */
  getStatus(): KBStatus {
    return {
      ready: this.ready,
      filesLoaded: Array.from(this.coreFiles.keys()),
      errors: [...this.errors],
      cacheSize: this.fileCache.size,
    };
  }

  getProjectName(): string {
    return this.config?.projectName ?? "the project";
  }

  isConfigured(): boolean {
    return this.config !== null;
  }
}

// Singleton
export const knowledgeBase = new KnowledgeBaseService();

export async function initializeKnowledgeBase(): Promise<void> {
  await knowledgeBase.initialize();
}
