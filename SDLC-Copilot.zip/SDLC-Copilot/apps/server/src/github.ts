/**
 * GitHub REST API helper
 * Fetches file contents directly using a Personal Access Token.
 * Works with both public and private repositories.
 * Includes retry with exponential backoff for transient failures.
 */

const GITHUB_API = "https://api.github.com";
const MAX_RETRIES = 2;

function getToken(): string {
  const token =
    process.env.COPILOT_GITHUB_TOKEN ||
    process.env.GH_TOKEN ||
    process.env.GITHUB_TOKEN;
  if (!token) {
    throw new Error(
      "No GitHub token found. Set GITHUB_TOKEN, GH_TOKEN, or COPILOT_GITHUB_TOKEN in your .env file."
    );
  }
  return token;
}

/**
 * Fetch a file's raw content from a GitHub repo via REST API.
 * Uses the authenticated token so it works for private repos.
 * Retries up to MAX_RETRIES times on transient (5xx/network) errors.
 */
export async function fetchFileContent(params: {
  owner: string;
  repo: string;
  filePath: string;
  ref?: string;
}): Promise<{ content: string; size: number; sha: string }> {
  const { owner, repo, filePath, ref = "main" } = params;
  const token = getToken();

  const url = `${GITHUB_API}/repos/${owner}/${repo}/contents/${filePath}?ref=${ref}`;
  const headers = {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github.v3+json",
    "User-Agent": "SDLC-Copilot",
  };

  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    if (attempt > 0) {
      const delay = Math.min(1000 * 2 ** (attempt - 1), 4000);
      console.log(`[github] Retry ${attempt}/${MAX_RETRIES} for ${filePath} after ${delay}ms`);
      await new Promise((r) => setTimeout(r, delay));
    }

    try {
      const res = await fetch(url, { headers });

      if (!res.ok) {
        const body = await res.text();
        if (res.status === 404) {
          throw new Error(
            `File not found: ${owner}/${repo}/${filePath}@${ref}. Check the repo name, file path, and branch.`
          );
        }
        if (res.status === 401 || res.status === 403) {
          throw new Error(
            `Access denied to ${owner}/${repo}. Your GITHUB_TOKEN may lack 'repo' scope or may be expired. (HTTP ${res.status})`
          );
        }
        // Retry on 5xx
        if (res.status >= 500 && attempt < MAX_RETRIES) {
          lastError = new Error(`GitHub API error ${res.status}: ${body}`);
          continue;
        }
        throw new Error(`GitHub API error ${res.status}: ${body}`);
      }

      const data = await res.json() as any;

      // GitHub returns base64-encoded content for files
      if (data.encoding === "base64" && data.content) {
        const decoded = Buffer.from(data.content, "base64").toString("utf-8");
        return { content: decoded, size: data.size, sha: data.sha };
      }

      // For very large files, GitHub may return a download URL
      if (data.download_url) {
        const rawRes = await fetch(data.download_url, {
          headers: {
            Authorization: `Bearer ${token}`,
            "User-Agent": "SDLC-Copilot",
          },
        });
        if (!rawRes.ok) {
          throw new Error(`Failed to download file from ${data.download_url}`);
        }
        const content = await rawRes.text();
        return { content, size: data.size, sha: data.sha };
      }

      throw new Error("Unexpected GitHub API response — no content or download_url");
    } catch (err: any) {
      if (err.message?.includes("not found") || err.message?.includes("Access denied")) {
        throw err;
      }
      lastError = err;
      if (attempt >= MAX_RETRIES) throw err;
    }
  }

  throw lastError || new Error(`Failed to fetch ${filePath} after ${MAX_RETRIES + 1} attempts`);
}
