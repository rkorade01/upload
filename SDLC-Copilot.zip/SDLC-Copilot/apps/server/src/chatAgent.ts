/**
 * Chat Agent
 *
 * Manages persistent Copilot SDK sessions keyed by a composite key:
 *   `${userId}:${clientSessionId}:${mode}`
 *
 * Mode "chat" — KB knowledge base assistant (fetch_kb_file tool)
 * Mode "ud"   — UD Analyst (fetch_kb_file + create_ud_file tools)
 *
 * Security:
 *   - Sessions are bound to userId (from auth middleware) to prevent hijacking
 *   - Max total sessions enforced to prevent memory exhaustion
 *   - Per-user session limits enforced
 *
 * Each session retains full conversation history in the SDK layer — only
 * the current message is passed per turn via session.send({ prompt }).
 */

import { approveAll, defineTool, type CopilotSession } from "@github/copilot-sdk";
import { getConfiguredModel, getCopilotClient } from "./copilot.js";
import { knowledgeBase } from "./knowledgeBase.js";
import { loadSystemPrompt, loadUDSystemPrompt } from "./prompts/prompt-loader.js";

// ─── Config ────────────────────────────────────────────────────────────────────

const MAX_TOTAL_SESSIONS = Number(process.env.MAX_TOTAL_SESSIONS) || 500;
const MAX_SESSIONS_PER_USER = Number(process.env.MAX_SESSIONS_PER_USER) || 10;

// ─── Session Map ───────────────────────────────────────────────────────────────

interface SessionEntry {
  session: CopilotSession;
  lastUsedAt: number; // ms timestamp
  userId: string;     // bound identity from auth middleware
}

/**
 * Composite key format: `${userId}:${clientSessionId}:${mode}`
 * Ensures sessions are scoped to the authenticated user.
 */
const sessions = new Map<string, SessionEntry>();

// ─── Shared Tool Builders ─────────────────────────────────────────────────────

/** Build the fetch_kb_file tool — shared by both "chat" and "ud" modes */
function buildFetchKBFileTool() {
  return defineTool("fetch_kb_file", {
    description:
      "Fetch the content of a file from the knowledge base repository. " +
      "Use the INDEX file to find which file path corresponds to a topic, " +
      "then call this tool to retrieve its full content.",
    parameters: {
      type: "object",
      properties: {
        filePath: {
          type: "string",
          description:
            "Relative path to the file within the KB repository " +
            "(e.g. 'auth-module.md', 'modules/payments.md'). " +
            "Do not include leading slashes.",
        },
      },
      required: ["filePath"],
    },
    handler: async (args: unknown) => {
      const { filePath } = args as { filePath: string };
      console.log(`[chatAgent] Tool: fetch_kb_file("${filePath}")`);
      try {
        const content = await knowledgeBase.fetchKBFileContent(filePath);
        return content;
      } catch (err: any) {
        console.error(`[chatAgent] fetch_kb_file error: ${err.message}`);
        return `Error fetching "${filePath}": ${err.message}`;
      }
    },
  });
}

/**
 * Build the create_ud_file tool — used in "ud" mode only.
 * The handler returns a success string to the LLM.
 * The actual file content is captured by the route layer from the
 * tool.execution_start event and emitted as a ud_file_ready SSE event.
 */
function buildCreateUDFileTool() {
  return defineTool("create_ud_file", {
    description:
      "Create the final Understanding Document (UD) file after the user has explicitly approved the draft. " +
      "ONLY call this tool after the user says 'approved', 'looks good', 'LGTM', 'finalize', or similar. " +
      "The file will be delivered to the user as a downloadable Markdown file.",
    parameters: {
      type: "object",
      properties: {
        filename: {
          type: "string",
          description:
            "Filename for the UD (e.g., 'UD_TICKET-123.md'). " +
            "Use the ticket ID from the requirement if available, otherwise use a descriptive name.",
        },
        content: {
          type: "string",
          description: "The complete, final UD content in Markdown format.",
        },
      },
      required: ["filename", "content"],
    },
    handler: async (args: unknown) => {
      const { filename } = args as { filename: string; content: string };
      console.log(`[chatAgent] Tool: create_ud_file("${filename}")`);
      // The route layer intercepts this via tool.execution_start and emits ud_file_ready.
      return `UD file "${filename}" has been created and sent to the user for download.`;
    },
  });
}

// ─── Session Lifecycle ─────────────────────────────────────────────────────────

/**
 * Get an existing session or create a new one.
 * Sessions are keyed by `${userId}:${sessionId}:${mode}` so they are bound to the
 * authenticated identity and cannot be hijacked.
 *
 * Enforces:
 *   - Max total sessions (returns error when at global capacity)
 *   - Max sessions per user
 *   - Evicts the oldest session for the user when per-user limit hit
 */
export async function getOrCreateSession(
  sessionId: string,
  mode: "chat" | "ud" = "chat",
  userId: string = "dev"
): Promise<CopilotSession> {
  const sessionKey = `${userId}:${sessionId}:${mode}`;

  const existing = sessions.get(sessionKey);
  if (existing) {
    if (existing.userId !== userId) {
      throw new Error("Session access denied");
    }
    existing.lastUsedAt = Date.now();
    console.log(`[chatAgent] Reusing session ${sessionKey}`);
    return existing.session;
  }

  // ── Enforce capacity limits ──────────────────────────────────────────────
  if (sessions.size >= MAX_TOTAL_SESSIONS) {
    // Evict the globally LRU session to make room
    let oldestKey: string | null = null;
    let oldestTime = Infinity;
    for (const [key, entry] of sessions.entries()) {
      if (entry.lastUsedAt < oldestTime) {
        oldestTime = entry.lastUsedAt;
        oldestKey = key;
      }
    }
    if (oldestKey) {
      console.log(`[chatAgent] Global session cap reached — evicting ${oldestKey}`);
      await destroySession(oldestKey);
    }
  }

  // Enforce per-user limit
  const userSessions = [...sessions.entries()].filter(([, e]) => e.userId === userId);
  if (userSessions.length >= MAX_SESSIONS_PER_USER) {
    // Evict the LRU session for this user
    const lru = userSessions.reduce((a, b) => (a[1].lastUsedAt < b[1].lastUsedAt ? a : b));
    console.log(`[chatAgent] Per-user cap reached for ${userId} — evicting ${lru[0]}`);
    await destroySession(lru[0]);
  }

  console.log(`[chatAgent] Creating new session ${sessionKey} (mode=${mode})`);

  const client = await getCopilotClient();
  const model = getConfiguredModel();

  const fetchKBFileTool = buildFetchKBFileTool();

  // Common auto-skip for user-input requests (Phase 1/3 — Phase 2 will add a real bridge)
  const onUserInputRequest = async (request: { question: string }) => {
    console.warn("[chatAgent] User input requested (auto-skip):", request.question);
    return { answer: "", wasFreeform: true };
  };

  let session: CopilotSession;

  if (mode === "ud") {
    // ── UD Analyst mode ────────────────────────────────────────────────────────
    const systemPromptContent = loadUDSystemPrompt({
      projectName: knowledgeBase.getProjectName(),
      coreContext: knowledgeBase.getCoreContext(),
    });

    const createUDFileTool = buildCreateUDFileTool();

    session = await client.createSession({
      model,
      streaming: true,
      systemMessage: { mode: "replace", content: systemPromptContent },
      tools: [fetchKBFileTool, createUDFileTool],
      infiniteSessions: { enabled: true },
      onPermissionRequest: approveAll,
      onUserInputRequest,
    });
  } else {
    // ── KB Chat mode (default) ─────────────────────────────────────────────────
    const systemPromptContent = loadSystemPrompt({
      projectName: knowledgeBase.getProjectName(),
      coreContext: knowledgeBase.getCoreContext(),
    });

    session = await client.createSession({
      model,
      streaming: true,
      systemMessage: { mode: "replace", content: systemPromptContent },
      tools: [fetchKBFileTool],
      infiniteSessions: { enabled: true },
      onPermissionRequest: approveAll,
      onUserInputRequest,
    });
  }

  console.log(`[chatAgent] Session created: ${sessionKey} (model=${model})`);
  sessions.set(sessionKey, { session, lastUsedAt: Date.now(), userId });

  return session;
}

/**
 * Destroy a specific session by its composite key and remove it from the map.
 * Called internally by destroyAllSessions and startSessionCleanup with keys
 * obtained directly from sessions.keys() — these are already composite keys.
 */
export async function destroySession(sessionKey: string): Promise<void> {
  const entry = sessions.get(sessionKey);
  if (!entry) return;

  sessions.delete(sessionKey);
  try {
    await entry.session.destroy();
    console.log(`[chatAgent] Session destroyed: ${sessionKey}`);
  } catch (err: any) {
    console.warn(`[chatAgent] Error destroying session ${sessionKey}:`, err.message);
  }
}

/**
 * Destroy all sessions. Called on server shutdown.
 */
export async function destroyAllSessions(): Promise<void> {
  const ids = Array.from(sessions.keys());
  console.log(`[chatAgent] Destroying ${ids.length} sessions...`);
  await Promise.allSettled(ids.map((id) => destroySession(id)));
}

/**
 * Start a periodic cleanup of idle sessions.
 * @param ttlMs - Sessions idle longer than this are destroyed (default: 30 min)
 */
export function startSessionCleanup(ttlMs = 30 * 60 * 1000): NodeJS.Timeout {
  const intervalMs = Math.min(ttlMs, 5 * 60 * 1000); // check at most every 5 min
  const timer = setInterval(async () => {
    const now = Date.now();
    const stale: string[] = [];

    for (const [id, entry] of sessions.entries()) {
      if (now - entry.lastUsedAt > ttlMs) {
        stale.push(id);
      }
    }

    if (stale.length > 0) {
      console.log(`[chatAgent] Cleaning up ${stale.length} idle session(s)`);
      await Promise.allSettled(stale.map((id) => destroySession(id)));
    }
  }, intervalMs);

  // Don't keep the process alive just for cleanup
  timer.unref();
  return timer;
}
