/**
 * Authentication middleware
 *
 * Supports two strategies:
 *   1. API key via `x-api-key` header   (for service-to-service / CLI)
 *   2. Bearer token via `Authorization`  (for future OAuth/JWT)
 *
 * API keys are loaded from the `API_KEYS` env var — a comma-separated list.
 * If `API_KEYS` is not set, auth is disabled (dev mode) with a startup warning.
 */
import type { Request, Response, NextFunction } from "express";
import crypto from "crypto";

// ─── Config ────────────────────────────────────────────────────────────────────

const API_KEYS: Set<string> = new Set(
  (process.env.API_KEYS || "")
    .split(",")
    .map((k) => k.trim())
    .filter(Boolean)
);

const AUTH_ENABLED = API_KEYS.size > 0;

if (!AUTH_ENABLED) {
  console.warn(
    "[auth] ⚠️  API_KEYS not set — authentication is DISABLED. " +
      "Set API_KEYS in .env for production."
  );
}

// ─── Helpers ───────────────────────────────────────────────────────────────────

/** Constant-time comparison to prevent timing attacks on key validation */
function safeCompare(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
}

function validateApiKey(key: string): boolean {
  for (const valid of API_KEYS) {
    if (safeCompare(key, valid)) return true;
  }
  return false;
}

// ─── Middleware ─────────────────────────────────────────────────────────────────

export interface AuthenticatedRequest extends Request {
  /** The authenticated identity (API key hash or "dev") */
  userId: string;
}

/**
 * Express middleware that validates authentication.
 * Attaches `req.userId` for downstream use (session binding, audit logs).
 */
export function authenticate(req: Request, res: Response, next: NextFunction): void {
  if (!AUTH_ENABLED) {
    // Dev mode — attach a deterministic identity
    (req as AuthenticatedRequest).userId = "dev";
    return next();
  }

  // Strategy 1: x-api-key header
  const apiKey = req.headers["x-api-key"];
  if (typeof apiKey === "string" && apiKey.length > 0) {
    if (validateApiKey(apiKey)) {
      // Use a hash of the key as userId (never store raw keys)
      (req as AuthenticatedRequest).userId = crypto
        .createHash("sha256")
        .update(apiKey)
        .digest("hex")
        .slice(0, 16);
      return next();
    }
    res.status(401).json({ error: "Invalid API key" });
    return;
  }

  // Strategy 2: Bearer token (placeholder — extend with JWT verification)
  const authHeader = req.headers.authorization;
  if (typeof authHeader === "string" && authHeader.startsWith("Bearer ")) {
    const token = authHeader.slice(7);
    if (validateApiKey(token)) {
      (req as AuthenticatedRequest).userId = crypto
        .createHash("sha256")
        .update(token)
        .digest("hex")
        .slice(0, 16);
      return next();
    }
    res.status(401).json({ error: "Invalid bearer token" });
    return;
  }

  res.status(401).json({ error: "Authentication required. Provide x-api-key header or Bearer token." });
}
