/**
 * Input validation middleware & helpers
 *
 * Provides:
 *   - UUID format validator
 *   - String length enforcement
 *   - Chat request validator (replaces inline validation in routes)
 *   - Summarize request validator with repo allowlist
 */

// ─── Constants ─────────────────────────────────────────────────────────────────

/** Max lengths for string inputs to prevent memory abuse */
export const MAX_LENGTHS = {
  sessionId: 64,
  message: 32_000,    // ~32K chars — generous but bounded
  owner: 100,
  repo: 100,
  filePath: 500,
  ref: 200,
  mode: 4,           // "chat" | "ud"
} as const;

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const SAFE_STRING_RE = /^[a-zA-Z0-9._\-/]+$/;

// ─── Helpers ───────────────────────────────────────────────────────────────────

export function isValidUUID(value: string): boolean {
  return UUID_RE.test(value);
}

/** Validates that a string is non-empty & within maxLength */
export function isValidString(value: unknown, maxLength: number): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= maxLength;
}

/** Validates that a GitHub owner/repo/ref/filePath is safe (no injection) */
export function isSafePathSegment(value: string): boolean {
  return SAFE_STRING_RE.test(value) && !value.includes("..");
}

// ─── Repo Allowlist (SSRF protection) ──────────────────────────────────────────

/**
 * If ALLOWED_REPOS is set (e.g. "facebook/react,myorg/myrepo"), only those
 * repos can be summarized. If unset, all repos accessible by the token are allowed
 * (dev mode — logged warning).
 */
const ALLOWED_REPOS: Set<string> | null = (() => {
  const raw = process.env.ALLOWED_REPOS;
  if (!raw) {
    console.warn(
      "[validate] ⚠️  ALLOWED_REPOS not set — summarize endpoint allows any repo the token can access. " +
        "Set ALLOWED_REPOS=owner/repo,owner2/repo2 in .env for production."
    );
    return null;
  }
  const repos = new Set(
    raw
      .split(",")
      .map((r) => r.trim().toLowerCase())
      .filter(Boolean)
  );
  console.log(`[validate] Repo allowlist: ${[...repos].join(", ")}`);
  return repos;
})();

export function isRepoAllowed(owner: string, repo: string): boolean {
  if (!ALLOWED_REPOS) return true; // dev mode
  return ALLOWED_REPOS.has(`${owner}/${repo}`.toLowerCase());
}

// ─── Chat Request Validation ───────────────────────────────────────────────────

export interface ValidatedChatRequest {
  sessionId: string;
  message: string;
  mode: "chat" | "ud";
}

export function validateChatRequest(body: any): {
  valid: true;
  data: ValidatedChatRequest;
} | { valid: false; error: string } {
  const { sessionId, message, mode } = body || {};

  if (!isValidString(sessionId, MAX_LENGTHS.sessionId)) {
    return { valid: false, error: `Missing or invalid 'sessionId' (max ${MAX_LENGTHS.sessionId} chars)` };
  }
  if (!isValidUUID(sessionId.trim())) {
    return { valid: false, error: "'sessionId' must be a valid UUID" };
  }
  if (!isValidString(message, MAX_LENGTHS.message)) {
    return { valid: false, error: `Missing or invalid 'message' (max ${MAX_LENGTHS.message} chars)` };
  }
  if (mode !== undefined && mode !== "chat" && mode !== "ud") {
    return { valid: false, error: "Invalid 'mode' — must be 'chat' or 'ud'" };
  }

  return {
    valid: true,
    data: {
      sessionId: sessionId.trim(),
      message: message.trim(),
      mode: mode === "ud" ? "ud" : "chat",
    },
  };
}

// ─── Summarize Request Validation ──────────────────────────────────────────────

export interface ValidatedSummarizeRequest {
  owner: string;
  repo: string;
  filePath: string;
  ref: string;
}

export function validateSummarizeRequest(body: any): {
  valid: true;
  data: ValidatedSummarizeRequest;
} | { valid: false; error: string } {
  const { owner, repo, filePath, ref } = body || {};

  if (!isValidString(owner, MAX_LENGTHS.owner)) {
    return { valid: false, error: `Missing or invalid 'owner' (max ${MAX_LENGTHS.owner} chars)` };
  }
  if (!isSafePathSegment(owner.trim())) {
    return { valid: false, error: "'owner' contains invalid characters" };
  }

  if (!isValidString(repo, MAX_LENGTHS.repo)) {
    return { valid: false, error: `Missing or invalid 'repo' (max ${MAX_LENGTHS.repo} chars)` };
  }
  if (!isSafePathSegment(repo.trim())) {
    return { valid: false, error: "'repo' contains invalid characters" };
  }

  if (!isValidString(filePath, MAX_LENGTHS.filePath)) {
    return { valid: false, error: `Missing or invalid 'filePath' (max ${MAX_LENGTHS.filePath} chars)` };
  }
  if (!isSafePathSegment(filePath.trim())) {
    return { valid: false, error: "'filePath' contains invalid characters" };
  }

  const refValue = ref?.trim() || "main";
  if (refValue.length > MAX_LENGTHS.ref || !isSafePathSegment(refValue)) {
    return { valid: false, error: "'ref' contains invalid characters or is too long" };
  }

  // SSRF check: is this repo on the allowlist?
  if (!isRepoAllowed(owner.trim(), repo.trim())) {
    return { valid: false, error: `Repository '${owner.trim()}/${repo.trim()}' is not in the allowed list` };
  }

  return {
    valid: true,
    data: {
      owner: owner.trim(),
      repo: repo.trim(),
      filePath: filePath.trim(),
      ref: refValue,
    },
  };
}
