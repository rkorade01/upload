/**
 * Rate limiting middleware
 *
 * Configurable via env vars:
 *   RATE_LIMIT_WINDOW_MS  — Window size in ms (default: 60000 = 1 min)
 *   RATE_LIMIT_MAX        — Max requests per window (default: 30)
 *   RATE_LIMIT_STREAM_MAX — Max streaming requests per window (default: 10)
 */
import rateLimit from "express-rate-limit";

const windowMs = Number(process.env.RATE_LIMIT_WINDOW_MS) || 60_000;
const max = Number(process.env.RATE_LIMIT_MAX) || 30;
const streamMax = Number(process.env.RATE_LIMIT_STREAM_MAX) || 10;

/** General API rate limiter — applies to all routes */
export const apiLimiter = rateLimit({
  windowMs,
  max,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests — please try again later" },
});

/** Stricter limiter for streaming / LLM endpoints (more expensive) */
export const streamLimiter = rateLimit({
  windowMs,
  max: streamMax,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many streaming requests — please try again later" },
});
