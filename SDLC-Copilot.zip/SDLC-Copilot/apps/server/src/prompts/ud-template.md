# Understanding Document (UD)

| Field | Value |
|---|---|
| **Ticket / Story** | [Ticket ID] |
| **Module / Feature** | [Module name] |
| **Author** | ⚠️ ASSUMED |
| **Date** | [Date] |
| **Status** | Draft |

---

## 1. Summary

### Current State
[Describe the existing behavior, data structure, or UI state before this change]

### Proposed Change
[Describe the new behavior, additions, or modifications this requirement introduces]

---

## 2. Requirement Details

[Paste or paraphrase the original requirement / user story / ticket description here. Include the ticket description verbatim if available.]

---

## 3. Data / Field Mapping

| Source Field | Source Object | Target Field | Target Object | Transformation / Note |
|---|---|---|---|---|
| | | | | |

> _Remove this section if no data mapping is involved._

---

## 4. Business Rules & Logic

| # | Rule | Trigger Condition | Expected Outcome |
|---|---|---|---|
| 1 | | | |

> _Enumerate all conditions, validations, calculations, and decision points. List exceptions and edge cases._

---

## 5. Acceptance Criteria

| # | Criterion | Test Approach |
|---|---|---|
| 1 | Given [context], when [action], then [expected result] | Manual / Automated / Unit |

---

## 6. Affected Components

| Component | File / Location | Change Type | Notes |
|---|---|---|---|
| | | New / Modified / No Change | |

> _Use KB file references where applicable (e.g., "Per `payments.md` — see PaymentService class")._

---

## 7. Code Preview (Optional)

```
// Key code changes, pseudocode, or configuration snippets
```

> _Remove if not yet determined or not applicable._

---

## 8. Prerequisites / Dependencies

| # | Dependency | Type | Status |
|---|---|---|---|
| 1 | | Field / Object / API / Config / Permission | Pending / Done |

---

## 9. Deployment & Release Order

1. [Step 1 — e.g., database schema migration / new object creation]
2. [Step 2 — e.g., backend service deploy]
3. [Step 3 — e.g., frontend deploy]
4. [Step 4 — e.g., configuration / feature flag / permission update]

> _Remove if not applicable._

---

## 10. Assumptions

| # | Assumption | Impact if Wrong |
|---|---|---|
| 1 | ⚠️ ASSUMED — [description of what was assumed] | [what breaks if this assumption is incorrect] |

---

## 11. Effort Estimate & Status

| Phase | Estimate | Assignee | Status |
|---|---|---|---|
| Analysis | | | ⚠️ ASSUMED |
| Development | | | ⚠️ ASSUMED |
| Testing | | | ⚠️ ASSUMED |
| Review & Deploy | | | ⚠️ ASSUMED |
