/**
 * Summarize route
 * POST /api/summarize        — returns full JSON response
 * POST /api/summarize/stream — returns SSE stream
 *
 * Hybrid approach:
 *  1. Fetch file via GitHub REST API (works for private repos with PAT)
 *  2. Summarize content via Copilot SDK LLM
 *
 * Security: SSRF protection via repo allowlist (ALLOWED_REPOS env var).
 * Requests are pre-authenticated by the auth middleware in index.ts.
 */
import { Router, Request, Response } from "express";
import type { SummarizeResponse } from "@sdlc-copilot/shared";
import { fetchFileContent } from "../github.js";
import { summarizeFileContent } from "../copilot.js";
import { validateSummarizeRequest, streamLimiter } from "../middleware/index.js";

const router = Router();

/**
 * POST /api/summarize
 * Returns the complete summary as JSON.
 */
router.post("/", async (req: Request, res: Response) => {
  const validation = validateSummarizeRequest(req.body);
  if (!validation.valid) {
    return res.status(400).json({ success: false, error: validation.error } satisfies SummarizeResponse);
  }
  const { owner, repo, filePath, ref } = validation.data;

  try {
    console.log(`[summarize] ${owner}/${repo}/${filePath}@${ref}`);

    // Step 1: Fetch file via GitHub REST API (uses GITHUB_TOKEN for private repos)
    console.log(`[summarize] Fetching file via GitHub API...`);
    const { content: fileContent } = await fetchFileContent({ owner, repo, filePath, ref });
    console.log(`[summarize] Fetched ${fileContent.length} chars`);

    // Step 2: Summarize via Copilot LLM
    console.log(`[summarize] Sending to Copilot for summarization...`);
    const summary = await summarizeFileContent({ owner, repo, filePath, ref: ref!, fileContent });

    const response: SummarizeResponse = {
      success: true,
      summary,
      metadata: { owner, repo, filePath, ref: ref! },
    };
    return res.json(response);
  } catch (err: any) {
    console.error("[summarize] Error:", err);
    return res.status(500).json({ success: false, error: err.message || "Internal server error" } satisfies SummarizeResponse);
  }
});

/**
 * POST /api/summarize/stream
 * Returns an SSE stream of summary chunks.
 */
router.post("/stream", streamLimiter, async (req: Request, res: Response) => {
  const validation = validateSummarizeRequest(req.body);
  if (!validation.valid) {
    res.status(400).json({ success: false, error: validation.error });
    return;
  }
  const { owner, repo, filePath, ref } = validation.data;

  // Set up SSE headers
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  // Send metadata event
  res.write(`data: ${JSON.stringify({ type: "metadata", data: JSON.stringify({ owner, repo, filePath, ref }) })}\n\n`);

  try {
    console.log(`[summarize/stream] ${owner}/${repo}/${filePath}@${ref}`);

    // Step 1: Fetch file via GitHub REST API
    console.log(`[summarize/stream] Fetching file via GitHub API...`);
    const { content: fileContent } = await fetchFileContent({ owner, repo, filePath, ref });
    console.log(`[summarize/stream] Fetched ${fileContent.length} chars`);

    // Step 2: Summarize via Copilot LLM with streaming
    await summarizeFileContent({
      owner,
      repo,
      filePath,
      ref: ref!,
      fileContent,
      onChunk: (chunk: string) => {
        res.write(`data: ${JSON.stringify({ type: "chunk", data: chunk })}\n\n`);
      },
    });

    res.write(`data: ${JSON.stringify({ type: "done", data: "" })}\n\n`);
  } catch (err: any) {
    console.error("[summarize/stream] Error:", err);
    res.write(`data: ${JSON.stringify({ type: "error", data: err.message || "Internal server error" })}\n\n`);
  } finally {
    res.end();
  }
});

export default router;
