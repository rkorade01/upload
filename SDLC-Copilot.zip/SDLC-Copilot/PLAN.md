# SDLC-Copilot: Knowledge Base Chat Agent — Implementation Plan

> **Created:** March 4, 2026  
> **Last Updated:** March 9, 2026 — Phase 4 (Production Hardening & Scalability) added; P0/P1 security implemented  
> **Last Verified:** March 4, 2026 — SDK v0.1.30 type definitions confirmed via unpkg  
> **Status:** Phase 1 ✅ Implemented · Phase 2 ⏳ Deferred · Phase 3 ✅ Implemented · **Phase 4 📋 Planned**  
> **SDK:** `@github/copilot-sdk` ^0.1.18 (verified against v0.1.30 types)  
> **Approach:** Additive — each phase builds on prior without modifying existing flows  
> **Note:** Zod is NOT used. `defineTool` accepts raw JSON schema objects directly.

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Impact Analysis — Existing Code](#impact-analysis)
4. [Phase 1 — KB Chat Agent (Core)](#phase-1)
5. [Phase 2 — Ask-User Bridge (Future)](#phase-2)
6. [Phase 3 — UD Creation Agent](#phase-3)
7. [File Inventory](#file-inventory)
8. [Implementation Steps](#implementation-steps)
9. [Environment Configuration](#environment-configuration)
10. [System Prompt Design](#system-prompt-design)
11. [API Contracts](#api-contracts)
12. [Verification Checklist](#verification-checklist)
13. [SDK Verification Notes](#sdk-verification-notes)
14. [Phase 4 — Production Hardening & Scalability](#phase-4)

---

## 1. Overview <a id="overview"></a>

Transform the existing File Summarizer into a **multi-turn, knowledge-base-powered chat agent**. The agent loads core context files from a configurable GitHub repo at startup, uses the Copilot SDK's `defineTool()` to autonomously fetch additional KB files on demand, and uses prompt engineering for clarifying questions.

**Key Design Decisions:**

| Decision | Choice | Rationale |
|---|---|---|
| KB file fetching | `defineTool("fetch_kb_file")` with raw JSON schema | SDK-native, AI decides when to fetch, no output parsing. Zod NOT needed — SDK accepts `Record<string, unknown>`. |
| Clarifying questions | System prompt instructions | Zero infrastructure cost, works today, upgrade path to `ask_user` later |
| Existing code impact | Additive only — no modification to working `summarize` flow | De-risks deployment, backward compatibility |
| Session management | **Server-side session Map keyed by UUID** — client sends `sessionId` per request | `session.send()` only accepts `{prompt: string}`, cannot inject history. Persistent sessions enable true multi-turn. |
| Permission handling | `approveAll` from SDK | `onPermissionRequest` is **required** (not optional) in `SessionConfig`; `approveAll` is the correct SDK export |
| Prompt templates | Externalized `.md` files | Generalizable — operators edit prompts, not code |
| Infinite sessions | Enabled | SDK handles context window compaction automatically |
| KB token | Own `fetchKBFileContent()` in `knowledgeBase.ts` | `github.ts::getToken()` does not support `KB_GITHUB_TOKEN`; `knowledgeBase.ts` handles its own token resolution |

---

## 2. Architecture <a id="architecture"></a>

### Current Architecture (Preserved)

```
[Web UI: FileSummarizer] → POST /api/summarize/stream → [Express Server]
                                                             ↓
                                                    fetchFileContent() → GitHub REST API
                                                             ↓
                                                    summarizeFileContent() → Copilot SDK Session
                                                             ↓
                                                         SSE stream ← chunks
```

### New Architecture (Added Alongside)

```
[Web UI: ChatInterface] → POST /api/chat/stream → [Express Server]
   (sends sessionId UUID)        (body: {sessionId, message})
                                                        ↓
                                              getOrCreateSession(sessionId)
                                              ─ sessions: Map<string, CopilotSession>
                                                        ↓
                                              Copilot SDK Session with:
                                                ├── systemMessage (from prompt templates + KB context)
                                                ├── defineTool("fetch_kb_file", rawJsonSchema)
                                                │     └── handler → knowledgeBase.fetchKBFileContent()
                                                │                     (own GitHub fetch, own token)
                                                ├── streaming: true
                                                ├── infiniteSessions: { enabled: true }
                                                └── onPermissionRequest: approveAll  ← REQUIRED
                                                        ↓
                                              session.send({ prompt: message })
                                                        ↓
                                              SSE stream ← chunks, tool_start, tool_complete, done
                                              (handlers unsubscribed on res.close to prevent leaks)
```

### Data Flow for a Typical Question

```
1. Frontend generates sessionId (UUID) on page load — stored in component state
2. User types: "How does the authentication module work?"
3. Frontend sends POST /api/chat/stream  { sessionId: "uuid-...", message: "How does auth work?" }
4. Server calls getOrCreateSession(sessionId):
   - First request: creates new SDK session, stores in Map, sets system prompt + tools
   - Subsequent requests: reuses existing session (multi-turn preserved in SDK layer)
5. Server calls session.send({ prompt: message })
6. LLM reads INDEX.md from system context → sees "auth → auth-module.md"
7. LLM calls fetch_kb_file({ filePath: "auth-module.md" })
   → Server emits SSE: { type: "tool_start", data: "Fetching auth-module.md..." }
   → Handler calls knowledgeBase.fetchKBFileContent() → own GitHub fetch → returns content
   → Server emits SSE: { type: "tool_complete", data: "Loaded auth-module.md" }
8. LLM receives file content, formulates answer
9. LLM streams response chunks → Server emits SSE: { type: "chunk", data: "..." }
10. Session idle → Server emits SSE: { type: "done" }
11. All per-request event handlers unsubscribed when res closes
```

---

## 3. Impact Analysis — Existing Code <a id="impact-analysis"></a>

### Files NOT Modified (Zero Impact)

| File | Reason |
|---|---|
| `apps/server/src/copilot.ts` | **No changes.** All existing functions (`getCopilotClient`, `warmUpCopilotClient`, `stopCopilotClient`, `summarizeFileContent`) remain intact. New chat logic goes in a separate `chatAgent.ts` file. The new file imports `getCopilotClient()` from copilot.ts — reusing the singleton. |
| `apps/server/src/github.ts` | **No changes.** KB service does NOT reuse `github.ts::fetchFileContent()` — it has its own `fetchKBFileContent()` to support `KB_GITHUB_TOKEN`. `github.ts` is only used by the summarize flow. |
| `apps/server/src/routes/summarize.ts` | **No changes.** Route stays mounted, fully functional. |
| `apps/web/src/components/FileSummarizer.tsx` | **No changes.** Component remains in codebase (not rendered by default, but preserved). |

### Files With Minor Additions

| File | Change | Risk |
|---|---|---|
| `apps/server/src/index.ts` | Add imports for `chatRouter`, `initializeKnowledgeBase`, `startSessionCleanup`, `destroyAllSessions`; mount route; call init + cleanup | **Very low** — additive only, no existing lines changed |
| `packages/shared/src/index.ts` | Add new interfaces alongside existing ones. Existing `SummarizeRequest`, `SummarizeResponse`, `StreamEvent` unchanged. | **Zero** — additive only |
| `apps/web/src/app/page.tsx` | Replace `<FileSummarizer />` with `<ChatInterface />` | **Low** — UI swap only. FileSummarizer.tsx stays in codebase. To revert: swap the import back. |
| `apps/web/src/app/layout.tsx` | Update title/description metadata strings | **Zero** — cosmetic |
| `apps/web/src/app/globals.css` | Append new CSS classes for chat UI | **Zero** — additive, no existing classes modified |
| `.env.example` | Append new KB variables. Existing variables unchanged. | **Zero** |

### New Files (No Impact on Existing)

| File | Purpose |
|---|---|
| `apps/server/src/knowledgeBase.ts` | KB repo loading & caching service |
| `apps/server/src/chatAgent.ts` | Chat session orchestrator with `defineTool` |
| `apps/server/src/routes/chat.ts` | Chat API routes |
| `apps/server/src/prompts/system-prompt.md` | Externalized system prompt template |
| `apps/server/src/prompts/prompt-loader.ts` | Prompt template reader & placeholder replacer |
| `apps/web/src/components/ChatInterface.tsx` | Chat UI component |

---

## 4. Phase 1 — KB Chat Agent (Core) <a id="phase-1"></a>

### What's Included

- ✅ KB repo loading at startup (3 configurable core files)
- ✅ `defineTool("fetch_kb_file")` for on-demand file fetching
- ✅ Multi-turn streaming chat via SSE
- ✅ Externalized system prompt templates
- ✅ Clarifying questions via prompt engineering (AI asks naturally)
- ✅ Tool execution visibility in UI (fetching indicator)
- ✅ LRU cache for fetched KB files
- ✅ Chat UI replacing FileSummarizer
- ✅ Infinite sessions for context window management
- ✅ Full backward compatibility with `/api/summarize` routes

### What's Deferred to Phase 2

- ⏳ `ask_user` bridge (SDK `onUserInputRequest` → SSE → REST callback)
- ⏳ Session persistence across page refreshes (localStorage)
- ⏳ Multiple active sessions
- ⏳ KB refresh endpoint (periodic or manual)
- ⏳ File attachment support

---

## 5. Phase 2 — Ask-User Bridge (Future) <a id="phase-2"></a>

When the `@github/copilot-sdk` stabilizes past technical preview, add:

1. `onUserInputRequest` handler in `chatAgent.ts` that:
   - Generates `requestId` (UUID)
   - Stores `{ resolve, reject, timeout }` in a pending map
   - Sends `ask_user` event via SSE
   - Returns Promise (blocks AI until resolved)
2. `POST /api/chat/respond` endpoint that resolves pending requests
3. Inline prompt UI in `ChatInterface.tsx` for `ask_user` events
4. Timeout handling (120s default) with graceful fallback

This is a purely additive upgrade — Phase 1 code needs no changes.

---

## 6. Phase 3 — UD Creation Agent <a id="phase-3"></a>

### Goal

Add a **UD (Understanding Document) creation workflow** to the existing KB chat UI. Users switch to "UD Creator" mode via a UI toggle, which spawns a dedicated Copilot SDK session with a UD-analyst system prompt. The LLM iteratively asks clarifying questions, drafts a UD using KB context, and — once approved — delivers the final `.md` file as a browser download.

### Key Design Decisions

| Decision | Choice | Rationale |
|---|---|---|
| Mode switching | **Explicit UI toggle** ("KB Chat" / "UD Creator" buttons) | User preference — avoids ambiguity of auto-detecting intent from message text |
| Session strategy | **New session per mode** — composite key `${sessionId}:${mode}` | UD mode needs a different system prompt (UD analyst role) and different tool set. Keeps KB chat context clean. Both sessions coexist in the Map. |
| UD file delivery | **Browser download** via Blob URL | No server filesystem dependency, no GitHub write access needed. Simple and reversible. |
| Questioning approach | **LLM-driven** — system prompt gives category guidance, LLM picks relevant questions | No rigid server-side question selection logic. LLM adapts based on requirement type + KB context. System prompt provides 7 question categories with examples but explicitly instructs "pick 3-7 relevant ones, don't dump all." |
| UD template | **Embedded in system prompt** as `{{UD_TEMPLATE}}` placeholder | Always in LLM context — no extra tool call needed. Template is a separate `.md` file injected at prompt assembly time. |
| UI scope (Phase 3) | **Minimal** — mode toggle only | Phase badge, approve/revise buttons, UD preview panel deferred to future enhancement. UD workflow runs entirely through chat messages. |
| Message state | **Separate arrays per mode** (`chatMessages` / `udMessages`) | Switching modes preserves conversation in each. No message loss. |

### What's Included

- ✅ Mode toggle in chat header ("KB Chat" / "UD Creator")
- ✅ Separate Copilot SDK session for UD mode (own system prompt, own tools)
- ✅ UD-analyst system prompt with iterative questioning loop
- ✅ Questioning guidance — 7 categories (Scope, Data, Logic, Integration, UI, Testing, Dependencies), LLM picks relevant ones
- ✅ `fetch_kb_file` tool — same as KB chat, for retrieving project context during UD creation
- ✅ `create_ud_file` tool — LLM calls this when user approves; emits file content via SSE
- ✅ UD template embedded in system prompt for consistent formatting
- ✅ `ud_file_ready` SSE event — carries `{ filename, content }` to frontend
- ✅ Browser download — frontend creates Blob URL + download link when UD is ready
- ✅ Per-mode message arrays and sessionId refs — switching preserves both conversations
- ✅ Approval gate — LLM only calls `create_ud_file` after explicit user approval ("approved", "looks good", "LGTM")
- ✅ `⚠️ ASSUMED` markers on unconfirmed items in draft UDs

### What's Deferred (Future Enhancements)

- ⏳ Phase indicators (Questioning → Drafting → Reviewing → Approved) as UI badges
- ⏳ Explicit Approve / Revise / Start Over buttons in UI
- ⏳ Side-panel UD preview (rendered Markdown alongside chat)
- ⏳ Auto-detect intent: if user types "Create UD" in KB Chat mode, suggest switching to UD mode
- ⏳ UD history — persist created UDs, list in sidebar for reference and re-editing
- ⏳ Server-side UD storage / GitHub commit of finalized UDs

### Architecture Addition (Phase 3)

```
[Web UI: ChatInterface]
   ├── mode: "chat" | "ud"              ← toggle in header
   ├── chatMessages[] + chatSessionId   ← KB Chat state
   └── udMessages[] + udSessionId       ← UD Creator state
              ↓
   POST /api/chat/stream  { sessionId, message, mode }
              ↓
[Express Server: routes/chat.ts]
   ├── Extract mode from body (default: "chat")
   └── getOrCreateSession(sessionId, mode)
              ↓
[chatAgent.ts]
   ├── Session Map key: "${sessionId}:${mode}"
   ├── mode === "chat":
   │     └── System prompt: system-prompt.md
   │         Tools: [fetch_kb_file]
   └── mode === "ud":
         └── System prompt: ud-system-prompt.md (with {{UD_TEMPLATE}})
             Tools: [fetch_kb_file, create_ud_file]
              ↓
[Copilot SDK Session]
   ├── LLM reads requirement, asks targeted questions
   ├── LLM fetches KB files for project context
   ├── LLM drafts UD using embedded template
   ├── LLM calls create_ud_file(filename, content) after approval
   └── Handler emits ud_file_ready SSE event
              ↓
[Frontend SSE handler]
   ├── Receives ud_file_ready event
   ├── Creates Blob from content
   └── Shows download link in chat
```

### UD Session Workflow (LLM Behavior)

```
1. User switches to "UD Creator" mode → new SDK session created with UD system prompt
2. User pastes/describes requirement
3. LLM reads core KB context (already in system prompt from startup) to understand project
4. LLM optionally calls fetch_kb_file to load specific KB files related to the requirement
5. LLM asks 3-7 targeted clarifying questions (picked from 7 categories based on requirement type)
6. User answers → LLM processes answers against KB context
7. If still unclear → LLM asks another round (max 3 rounds before drafting with assumptions)
8. LLM generates UD draft following the embedded template
9. LLM presents draft and asks: "Approved? Or provide feedback to revise."
10. User provides feedback → LLM revises specific sections, shows what changed
11. Repeat 10 until user says "approved" / "looks good" / "finalize" / "LGTM"
12. LLM calls create_ud_file({ filename: "UD_TICKET-ID.md", content: "..." })
13. Tool handler returns success → LLM confirms creation
14. SSE emits ud_file_ready → Frontend shows download link
```

### `create_ud_file` Tool Definition

```typescript
defineTool("create_ud_file", {
  description:
    "Create the final Understanding Document (UD) file after user approval. " +
    "Only call this AFTER the user has explicitly approved the UD draft. " +
    "The file will be delivered to the user as a downloadable markdown file.",
  parameters: {
    type: "object",
    properties: {
      filename: {
        type: "string",
        description:
          "Filename for the UD (e.g., 'UD_TICKET-123.md'). " +
          "Use the ticket ID from the requirement if available.",
      },
      content: {
        type: "string",
        description: "The complete UD content in Markdown format.",
      },
    },
    required: ["filename", "content"],
  },
  handler: async (args: unknown) => {
    const { filename, content } = args as { filename: string; content: string };
    // Content is emitted via SSE (ud_file_ready event) — see routes/chat.ts
    return `UD file "${filename}" created successfully and sent to the user for download.`;
  },
});
```

### UD System Prompt Overview

**File:** `apps/server/src/prompts/ud-system-prompt.md`

The UD system prompt defines three core sections:

1. **Role & Behavior** — You are a UD Analyst for `{{KB_PROJECT_NAME}}`. Follow a strict iterative loop: receive requirement → explore KB → question → draft → revise → approve.

2. **Questioning Guidance** — 7 categories (Scope, Data/Mapping, Business Logic, Integration, UI, Testing, Dependencies) with example question patterns. LLM instruction: "Pick 3-7 relevant questions per round based on requirement type. Do NOT ask all categories at once."

3. **UD Template** — Full template structure injected via `{{UD_TEMPLATE}}`. LLM fills sections, removes inapplicable ones, marks assumptions with `⚠️ ASSUMED`.

**Placeholders:**
| Placeholder | Source |
|---|---|
| `{{KB_PROJECT_NAME}}` | `process.env.KB_PROJECT_NAME` |
| `{{CORE_CONTEXT}}` | `knowledgeBase.getCoreContext()` |
| `{{UD_TEMPLATE}}` | Contents of `ud-template.md` file |

---

## 7. File Inventory <a id="file-inventory"></a>

### Complete File Map (Phase 1)

```
apps/server/src/
  ├── index.ts               ← MINOR EDIT (imports + shutdown hooks added)
  ├── copilot.ts             ← NO CHANGES
  ├── github.ts              ← NO CHANGES (not used by KB)
  ├── chatAgent.ts           ← NEW — session Map + chat session with defineTool
  ├── knowledgeBase.ts       ← NEW — KB loading, own GitHub fetch & token
  ├── prompts/
  │   ├── system-prompt.md   ← NEW — externalized system prompt
  │   └── prompt-loader.ts   ← NEW — template reader
  └── routes/
      ├── summarize.ts       ← NO CHANGES
      └── chat.ts            ← NEW — chat API routes

apps/web/src/
  ├── app/
  │   ├── page.tsx           ← MINOR EDIT (swap component)
  │   ├── layout.tsx         ← MINOR EDIT (update meta)
  │   └── globals.css        ← MINOR EDIT (append classes)
  └── components/
      ├── FileSummarizer.tsx  ← NO CHANGES (kept for reference)
      └── ChatInterface.tsx   ← NEW — chat UI (with sessionId state)

packages/shared/src/
  └── index.ts               ← MINOR EDIT (add types alongside existing)

.env.example                  ← MINOR EDIT (append variables)
```

### Phase 3 Additions & Modifications

```
apps/server/src/
  ├── chatAgent.ts                ← MODIFY — composite session key, mode param,
  │                                           create_ud_file tool definition
  ├── prompts/
  │   ├── prompt-loader.ts        ← MODIFY — add loadUDSystemPrompt() function
  │   ├── ud-system-prompt.md     ← NEW — UD analyst system prompt template
  │   └── ud-template.md          ← NEW — UD template for LLM reference
  └── routes/
      └── chat.ts                 ← MODIFY — extract mode, pass to session creator,
                                              emit ud_file_ready SSE event

apps/web/src/
  └── components/
      └── ChatInterface.tsx       ← MODIFY — mode toggle, per-mode state arrays,
                                              per-mode sessionIds, ud_file_ready handler,
                                              download link UI

packages/shared/src/
  └── index.ts                    ← MODIFY — add mode to ChatRequest,
                                              add ud_file_ready event type,
                                              add UDFilePayload interface
```

**Phase 3 Impact Summary:**

| File | Action | Existing Code Changes |
|---|---|---|
| `packages/shared/src/index.ts` | Modify | Add `mode?` field to `ChatRequest`, add `"ud_file_ready"` to event union, add `UDFilePayload` type. No existing types changed. |
| `apps/server/src/chatAgent.ts` | Modify | Change session Map key from `sessionId` → `${sessionId}:${mode}`. Add `mode` parameter to `getOrCreateSession()`. Add UD branch with different prompt + tools. Existing "chat" mode logic untouched. |
| `apps/server/src/prompts/prompt-loader.ts` | Modify | Add `loadUDSystemPrompt()` alongside existing `loadSystemPrompt()`. No changes to existing function. |
| `apps/server/src/prompts/ud-system-prompt.md` | **NEW** | UD analyst system prompt with questioning guidance + template |
| `apps/server/src/prompts/ud-template.md` | **NEW** | UD template content for LLM reference |
| `apps/server/src/routes/chat.ts` | Modify | Extract `mode` from request body, pass to `getOrCreateSession()`, handle `create_ud_file` tool events. Existing SSE logic untouched. |
| `apps/web/src/components/ChatInterface.tsx` | Modify | Add mode state + toggle, per-mode message arrays + sessionIds, `ud_file_ready` handler, download UI. Existing chat rendering untouched. |

---

## 8. Implementation Steps <a id="implementation-steps"></a>

### Step 1: Environment Configuration

**File:** `.env.example`  
**Action:** Append KB variables (existing variables untouched)

New variables:
```env
# ─── Knowledge Base Repo ───────────────────────────
KB_REPO_OWNER=your-org
KB_REPO_NAME=your-kb-repo
KB_REPO_REF=main
KB_CORE_FILES=copilot-instructions.md,INDEX.md,README.md
KB_FILE_EXTENSIONS=.md
KB_PROJECT_NAME=My Project
# Optional: dedicated token for KB repo (falls back to GITHUB_TOKEN)
# KB_GITHUB_TOKEN=ghp_your_kb_token_here
```

### Step 2: Shared Types

**File:** `packages/shared/src/index.ts`  
**Action:** Add new interfaces below existing ones

```typescript
// ─── Chat Types (new) ─────────────────────────────

/** Single chat message for display purposes */
export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

/**
 * Request to the chat endpoint.
 * Client generates a stable UUID sessionId on page load and sends it with every message.
 * Server maintains the actual SDK session in a Map keyed by sessionId.
 * Only the current message is sent — not the full history — because the SDK session
 * retains conversation context server-side.
 */
export interface ChatRequest {
  sessionId: string;   // UUID generated on frontend page load
  message: string;     // Current user message only
}

/** Streaming event types for chat SSE */
export type ChatStreamEventType =
  | "chunk"         // Assistant text delta
  | "done"          // Stream complete
  | "error"         // Error occurred
  | "tool_start"    // Tool execution started (fetch_kb_file)
  | "tool_complete" // Tool execution completed
  | "status";       // Status message (e.g., KB loading)

export interface ChatStreamEvent {
  type: ChatStreamEventType;
  data: string;
}
```

### Step 3: Knowledge Base Service

**File:** `apps/server/src/knowledgeBase.ts` (NEW)  
**Dependencies:** None from this repo. Own GitHub fetch implementation.

> **Why not reuse `github.ts::fetchFileContent()`?**  
> `github.ts::getToken()` reads `COPILOT_GITHUB_TOKEN || GH_TOKEN || GITHUB_TOKEN` and has no
> awareness of `KB_GITHUB_TOKEN`. To support a dedicated KB repo token without modifying the
> committed `github.ts`, `knowledgeBase.ts` implements its own `fetchKBFileContent()` with
> token order: `KB_GITHUB_TOKEN → COPILOT_GITHUB_TOKEN → GITHUB_TOKEN`.

```
KnowledgeBaseService (singleton)
├── initialize()              — fetch core files at startup
├── getCoreContext()          — return formatted core files for system prompt
├── fetchKBFileContent(path)  — on-demand fetch with LRU cache
│     Token order: KB_GITHUB_TOKEN → COPILOT_GITHUB_TOKEN → GITHUB_TOKEN
├── getStatus()               — { ready, filesLoaded, errors }
└── Internal:
    ├── coreFiles: Map<string, string>      — preloaded core content
    ├── fileCache: Map<string, string>      — LRU cache (50 entries default)
    └── config from env vars
```

**Key behaviors:**
- Own fetch implementation using GitHub REST API (no dependency on `github.ts`)
- Graceful partial loading — if one core file fails, others still load
- Validates file extensions against `KB_FILE_EXTENSIONS` whitelist
- LRU cache with configurable max size (default 50)

### Step 4: Prompt Templates

**File:** `apps/server/src/prompts/system-prompt.md` (NEW)

Template with placeholders:
- `{{KB_PROJECT_NAME}}` — from env
- `{{CORE_CONTEXT}}` — injected core file contents
- `{{CLARIFICATION_RULES}}` — when to ask clarifying questions

**File:** `apps/server/src/prompts/prompt-loader.ts` (NEW)

Reads `.md` template from disk, replaces placeholders, returns assembled string.

> **Note:** `tsx watch` resolves source-relative paths correctly in dev. For a compiled
> `dist/` deployment, `.md` files must be copied manually — accepted limitation for Phase 1.

### Step 5: Chat Agent

**File:** `apps/server/src/chatAgent.ts` (NEW)  
**Dependencies:** `copilot.ts` (`getCopilotClient`), `knowledgeBase.ts`, `prompt-loader.ts`

```
Session Map (module-level singleton):
  sessions: Map<string, CopilotSession>

getOrCreateSession(sessionId: string) → CopilotSession
├── If sessions.has(sessionId): return existing session (multi-turn preserved)
├── Else: create new session via getCopilotClient() (reused singleton)
│     ├── systemMessage: { mode: "replace", content: loadedPrompt }
│     ├── tools: [
│     │     defineTool("fetch_kb_file", {
│     │         description: "Fetch a file from the KB repository",
│     │         parameters: {                    ← raw JSON schema, NOT Zod
│     │           type: "object",
│     │           properties: {
│     │             filePath: { type: "string", description: "..." }
│     │           },
│     │           required: ["filePath"]
│     │         },
│     │         handler: async ({ filePath }) =>
│     │             knowledgeBase.fetchKBFileContent(filePath)
│     │     })
│     │   ]
│     ├── streaming: true
│     ├── infiniteSessions: { enabled: true }
│     └── onPermissionRequest: approveAll   ← REQUIRED field; import from SDK
│
destroySession(sessionId: string) → void
destroyAllSessions() → void          ← called on server shutdown
startSessionCleanup(ttlMs: number)   ← idle session reaper (setInterval)
```

> **Why raw JSON schema instead of Zod?**  
> The SDK's `ZodSchema` interface expects a `.toJSONSchema()` method on the Zod schema object.
> Zod v4 (4.x) replaced this with a standalone `z.toJSONSchema(schema)` function — the method
> no longer exists on schema instances. Rather than downgrade to Zod v3 or add workaround shims,
> we pass raw `Record<string, unknown>` JSON schema objects which the SDK also accepts natively.
>
> **Why `approveAll`?**  
> `SessionConfig.onPermissionRequest` is not optional (no `?` in the type definition).
> The SDK exports `approveAll` as a ready-made handler that approves all tool executions.

**SSE handler pattern (per-request, no leaks):**
```typescript
// In routes/chat.ts — handlers registered per request, unsubscribed on close
const unsubFns: Array<() => void> = [];
unsubFns.push(session.on("assistant.message_delta", handler));
unsubFns.push(session.on("tool.execution_start", handler));
// ...
res.on("close", () => unsubFns.forEach(fn => fn()));
```

> **Why per-request unsubscribe?**  
> Sessions are reused across HTTP requests (session Map). If handlers from request N are not
> removed, they fire on request N+1 response objects — writing to closed responses and leaking
> memory. `session.on()` returns a `() => void` unsubscribe function; store and call them all
> when the response closes.

**Critical design choice:** This file does NOT modify `copilot.ts`. It imports the shared `getCopilotClient()` and creates its own sessions with different configuration. `summarizeFileContent()` in `copilot.ts` continues to work independently.

### Step 6: Chat API Routes

**File:** `apps/server/src/routes/chat.ts` (NEW)

| Route | Method | Purpose |
|---|---|---|
| `/api/chat/stream` | POST | Main chat endpoint — receives `ChatRequest`, returns SSE stream |
| `/api/chat/status` | GET | Returns KB status: `{ ready, filesLoaded, errors }` |

**`POST /api/chat/stream` flow:**
1. Validate request body: `{ sessionId: string, message: string }`
2. Call `getOrCreateSession(sessionId)` — reuses if exists, creates if new
3. Set SSE headers (`Content-Type: text/event-stream`, `Cache-Control: no-cache`)
4. Register per-request event handlers (with unsubscribe tracking):
   - `assistant.message_delta` → `{ type: "chunk", data: deltaContent }`
   - `tool.execution_start` → `{ type: "tool_start", data: "Fetching filePath..." }`
   - `tool.execution_complete` → `{ type: "tool_complete", data: "Loaded filePath" }`
   - `session.idle` → `{ type: "done" }` + end response
   - errors → `{ type: "error", data: message }`
5. Wire `res.on("close", ...)` to call all unsubscribe functions
6. Call `session.send({ prompt: message })`

### Step 7: Server Entry Point Update

**File:** `apps/server/src/index.ts`  
**Action:** Add imports and startup/shutdown hooks (no existing lines changed)

```typescript
// NEW imports
import chatRouter from "./routes/chat.js";
import { initializeKnowledgeBase } from "./knowledgeBase.js";
import { startSessionCleanup, destroyAllSessions } from "./chatAgent.js";

// NEW: mount route (alongside existing summarize route)
app.use("/api/chat", chatRouter);

// NEW: inside server.listen callback, after warmUpCopilotClient()
await initializeKnowledgeBase();
startSessionCleanup(30 * 60 * 1000); // reap sessions idle > 30 min

// NEW: in graceful shutdown handler (alongside stopCopilotClient())
destroyAllSessions();
```

Updated console output:
```
🚀 SDLC-Copilot server running at http://localhost:4000
   POST /api/summarize        — full JSON response (existing)
   POST /api/summarize/stream  — SSE streaming response (existing)
   POST /api/chat/stream       — KB chat streaming (NEW)
   GET  /api/chat/status       — KB status (NEW)
   GET  /api/health            — health check
```

### Step 8: Chat UI Component

**File:** `apps/web/src/components/ChatInterface.tsx` (NEW)

**State:**
```typescript
sessionId: string             // UUID generated once on component mount (useRef or useState)
messages: ChatMessage[]       // conversation history for display only
isLoading: boolean            // AI is processing
toolActivity: string | null   // "Fetching auth-module.md..." indicator
error: string | null          // inline error
```

> **`sessionId` is generated once on mount** (e.g., `crypto.randomUUID()`) and reused for the
> lifetime of the component. It is sent with every `POST /api/chat/stream` request so the server
> can locate the matching SDK session in the Map.

**Layout:**
```
┌──────────────────────────────────┐
│  Header: "SDLC Copilot — KB"    │
├──────────────────────────────────┤
│                                  │
│  Message bubble (user)           │
│  Message bubble (assistant)      │ ← scrollable, react-markdown
│  Message bubble (user)           │
│  [Fetching auth-module.md...]    │ ← tool activity indicator
│  Message bubble (assistant)      │
│                                  │
├──────────────────────────────────┤
│  [Type your question...]  [Send] │
└──────────────────────────────────┘
```

**SSE handler:** Reuses the `ReadableStream` + `getReader()` + `TextDecoder` + line-split-on-`\n` + `data: ` prefix parse pattern from `FileSummarizer.tsx` (proven working). Extended with `tool_start` / `tool_complete` / `status` event types.

**Request body sent per message:**
```json
{ "sessionId": "3f8a2c1d-...", "message": "How does auth work?" }
```

### Step 9: Frontend Page & Styles

**File:** `apps/web/src/app/page.tsx` — swap `<FileSummarizer />` for `<ChatInterface />`  
**File:** `apps/web/src/app/layout.tsx` — update metadata strings  
**File:** `apps/web/src/app/globals.css` — append chat CSS classes (no existing classes modified)

### Step 10: Dependencies

No new npm packages are required.

- **Zod**: NOT installed. `defineTool` accepts raw JSON schema (`Record<string, unknown>`). See [Step 5](#step-5-chat-agent) for rationale.
- `crypto.randomUUID()` — available natively in Node.js 14.17+ and modern browsers. No package needed.
- All other capabilities come from existing dependencies (`@github/copilot-sdk`, `express`, React, Next.js).

### Phase 1 Dependency / Execution Order

```
Step 1  (.env.example)          ── independent
Step 2  (shared types)          ── independent
Step 3  (knowledgeBase.ts)      ── independent (own fetch, no deps from this repo)
Step 4  (prompts/)              ── independent
Step 5  (chatAgent.ts)          ── depends on: Steps 2, 3, 4 + copilot.ts (existing)
Step 6  (routes/chat.ts)        ── depends on: Step 5
Step 7  (index.ts update)       ── depends on: Steps 3, 6
Step 8  (ChatInterface.tsx)     ── depends on: Step 2 (types)
Step 9  (page/layout/css)       ── depends on: Step 8
Step 10 (no installs needed)    ── N/A
```

**Parallelizable:** Steps 1, 2, 3, 4 can all run simultaneously (all independent).  
**Critical path:** Step 3 + Step 4 → Step 5 → Step 6 → Step 7 (server chain)  
**Frontend path:** Step 2 → Step 8 → Step 9 (can run in parallel with server chain after Step 2)

### Phase 3 Implementation Steps

> These steps are all **additive** to Phase 1. No Phase 1 code is deleted — only extended.

#### Step 11: Shared Types — UD Extensions

**File:** `packages/shared/src/index.ts`  
**Action:** Extend existing types (no existing types modified)

```typescript
// ─── UD Extensions (Phase 3) ──────────────────────

/** Updated ChatRequest — add optional mode */
export interface ChatRequest {
  sessionId: string;
  message: string;
  mode?: "chat" | "ud";  // NEW — defaults to "chat" for backward compatibility
}

/** Add to ChatStreamEventType union */
export type ChatStreamEventType =
  | "chunk" | "done" | "error" | "tool_start" | "tool_complete" | "status"
  | "ud_file_ready";   // NEW — carries UD file payload for download

/** Payload for ud_file_ready events */
export interface UDFilePayload {
  filename: string;  // e.g., "UD_TICKET-123.md"
  content: string;   // Full UD Markdown content
}
```

#### Step 12: UD System Prompt

**File:** `apps/server/src/prompts/ud-system-prompt.md` (NEW)

Template with placeholders:
- `{{KB_PROJECT_NAME}}` — project name from env
- `{{CORE_CONTEXT}}` — core KB files injected at session creation
- `{{UD_TEMPLATE}}` — full UD template structure for the LLM to follow

**Structure:**
```markdown
You are a **UD Analyst** for the {{KB_PROJECT_NAME}} project...

## Your Knowledge Base
{{CORE_CONTEXT}}

## Core Behavior
Strict iterative loop: Receive → Explore KB → Question → Draft → Revise → Create file...

## Questioning Categories
[7 categories with example question patterns — Scope, Data, Logic, Integration, UI, Testing, Dependencies]
"Pick 3-7 relevant questions per round based on requirement type. Do NOT ask all categories."

## UD Template
{{UD_TEMPLATE}}

## Approval Rules
Only call create_ud_file after explicit approval: "approved", "looks good", "finalize", "LGTM"
Mark assumptions with ⚠️ ASSUMED...

## Tools
- fetch_kb_file — retrieve additional KB files for project context
- create_ud_file — create the final UD file (only after approval)
```

#### Step 13: UD Template File

**File:** `apps/server/src/prompts/ud-template.md` (NEW)  
**Action:** Copy the UD template structure (section headers, table formats, placeholder descriptions). This is injected into the UD system prompt as `{{UD_TEMPLATE}}` so the LLM always has the target format in context.

**Sections included:** Summary (Current/Proposed), Requirement Details, Data/Field Mapping, Business Rules & Logic, Acceptance Criteria, Affected Components, Code Preview, Prerequisites, Deploy/Release Order, Assumptions, Effort/Status.

#### Step 14: Prompt Loader Update

**File:** `apps/server/src/prompts/prompt-loader.ts`  
**Action:** Add `loadUDSystemPrompt()` alongside existing `loadSystemPrompt()` (existing function untouched)

```typescript
/** Load and assemble the UD system prompt template. */
export function loadUDSystemPrompt(values: {
  projectName: string;
  coreContext: string;
}): string {
  const templatePath = join(__dirname, "ud-system-prompt.md");
  const udTemplatePath = join(__dirname, "ud-template.md");

  let template = readFileSync(templatePath, "utf-8");
  let udTemplate: string;
  try {
    udTemplate = readFileSync(udTemplatePath, "utf-8");
  } catch {
    udTemplate = "(UD template not found — use your best judgment for structure)";
  }

  return template
    .replace(/\{\{KB_PROJECT_NAME\}\}/g, values.projectName)
    .replace(/\{\{CORE_CONTEXT\}\}/g, values.coreContext)
    .replace(/\{\{UD_TEMPLATE\}\}/g, udTemplate);
}
```

#### Step 15: Chat Agent — Mode-Aware Sessions

**File:** `apps/server/src/chatAgent.ts`  
**Action:** Extend `getOrCreateSession()` to accept `mode` parameter

**Key changes:**

1. **Composite session key:** `${sessionId}:${mode}` — allows KB Chat and UD sessions to coexist for the same client.

2. **`getOrCreateSession(sessionId, mode)` signature change:**
   ```typescript
   export async function getOrCreateSession(
     sessionId: string,
     mode: "chat" | "ud" = "chat"
   ): Promise<CopilotSession>
   ```

3. **Mode branching:** When `mode === "ud"`:
   - Use `loadUDSystemPrompt()` instead of `loadSystemPrompt()`
   - Define `create_ud_file` tool (see tool definition in Phase 3 section above)
   - Include both `fetch_kb_file` and `create_ud_file` in tools array

4. **create_ud_file tool handler:** Returns a success string to the LLM. The actual file content is captured in the route layer (Step 16) and emitted as a `ud_file_ready` SSE event.

**Existing "chat" mode path unchanged** — the default `mode === "chat"` follows the exact same code path as Phase 1.

#### Step 16: Chat Route — Mode & UD File Events

**File:** `apps/server/src/routes/chat.ts`  
**Action:** Extract `mode`, pass to session creator, handle UD file SSE events

**Key changes:**

1. **Extract `mode`** from request body (default `"chat"` for backward compatibility):
   ```typescript
   const mode = (body.mode === "ud") ? "ud" : "chat";
   ```

2. **Pass to session creator:**
   ```typescript
   const session = await getOrCreateSession(sessionId, mode);
   ```

3. **Capture `create_ud_file` tool args in SSE:**
   In the `tool.execution_start` handler, when `toolName === "create_ud_file"`:
   ```typescript
   if (event.data.toolName === "create_ud_file") {
     const args = event.data.arguments as { filename?: string; content?: string };
     if (args?.filename && args?.content) {
       sseWrite(res, "ud_file_ready", JSON.stringify({
         filename: args.filename,
         content: args.content,
       }));
     }
   }
   ```

4. **Validate mode:** Reject unknown mode values with 400 status.

#### Step 17: Chat UI — Mode Toggle & UD Download

**File:** `apps/web/src/components/ChatInterface.tsx`  
**Action:** Add mode toggle, per-mode state, UD download handler

**Key changes:**

1. **Mode state:**
   ```typescript
   const [mode, setMode] = useState<"chat" | "ud">("chat");
   ```

2. **Per-mode message arrays:**
   ```typescript
   const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
   const [udMessages, setUdMessages] = useState<ChatMessage[]>([]);
   // Active messages derived from mode
   const messages = mode === "chat" ? chatMessages : udMessages;
   const setMessages = mode === "chat" ? setChatMessages : setUdMessages;
   ```

3. **Per-mode session IDs:** Separate `useRef` for each mode. UD sessionId generated lazily on first toggle to UD mode.

4. **Mode toggle in header:** Two buttons ("KB Chat" / "UD Creator") replacing the static subtitle. Active mode highlighted.

5. **Send mode in request:**
   ```typescript
   body: JSON.stringify({ sessionId: activeSessionId, message: text, mode })
   ```

6. **Handle `ud_file_ready` SSE event:**
   ```typescript
   case "ud_file_ready": {
     const payload = JSON.parse(event.data) as UDFilePayload;
     const blob = new Blob([payload.content], { type: "text/markdown" });
     const url = URL.createObjectURL(blob);
     // Add download link as an assistant message or inline UI element
     break;
   }
   ```

7. **UD mode empty state:** "Paste or describe your requirement to start creating an Understanding Document."

8. **Header subtitle:** Dynamic based on mode — "Knowledge Base Assistant" / "UD Creation Agent"

#### Step 18: Phase 3 Dependencies

No new npm packages required. Phase 3 uses the same `@github/copilot-sdk`, Express, React, and Next.js stack as Phase 1.

---

### Phase 3 Dependency / Execution Order

```
Step 11 (shared types)             ── independent
Step 12 (ud-system-prompt.md)      ── independent
Step 13 (ud-template.md)           ── independent
Step 14 (prompt-loader.ts update)  ── depends on: Steps 12, 13
Step 15 (chatAgent.ts update)      ── depends on: Steps 11, 14
Step 16 (routes/chat.ts update)    ── depends on: Steps 11, 15
Step 17 (ChatInterface.tsx update) ── depends on: Step 11
Step 18 (no installs needed)       ── N/A
```

**Parallelizable:** Steps 11, 12, 13 can all run simultaneously.  
**Critical path:** Step 12 + 13 → Step 14 → Step 15 → Step 16 (server chain)  
**Frontend path:** Step 11 → Step 17 (can run in parallel with server chain after Step 11)

---

## 9. Environment Configuration <a id="environment-configuration"></a>

### Full `.env` Template (Phase 1)

```env
# ─── Existing (unchanged) ──────────────────────────
GITHUB_TOKEN=ghp_your_token_here
# COPILOT_TOKEN=gho_your_oauth_token_here
COPILOT_MODEL=claude-sonnet-4-6
SERVER_PORT=4000
WEB_ORIGIN=http://localhost:3000
NEXT_PUBLIC_API_URL=http://localhost:4000

# ─── Knowledge Base Repo (new) ─────────────────────
KB_REPO_OWNER=your-org
KB_REPO_NAME=your-kb-repo
KB_REPO_REF=main
KB_CORE_FILES=copilot-instructions.md,INDEX.md,README.md
KB_FILE_EXTENSIONS=.md
KB_PROJECT_NAME=My Project
# KB_GITHUB_TOKEN=ghp_your_kb_token_here

# ─── Security (Phase 4 — March 9, 2026) ───────────
# Comma-separated API keys. If unset, auth is disabled (dev mode only).
API_KEYS=key1,key2
# Comma-separated owner/repo pairs the summarize endpoint may access.
ALLOWED_REPOS=myorg/myrepo,myorg/another-repo
NEXT_PUBLIC_API_KEY=your_api_key_here

# ─── Session Limits (Phase 4) ──────────────────────
MAX_TOTAL_SESSIONS=500
MAX_SESSIONS_PER_USER=10

# ─── Rate Limiting (Phase 4) ───────────────────────
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX=30
RATE_LIMIT_STREAM_MAX=10

# ─── SSE (Phase 4) ─────────────────────────────────
SSE_HEARTBEAT_MS=20000
```

### Token Resolution for KB

```
KB_GITHUB_TOKEN  →  COPILOT_GITHUB_TOKEN  →  GITHUB_TOKEN  →  Error
   (dedicated)          (shared Copilot)         (shared)       (startup fails gracefully)
```

---

## 10. System Prompt Design <a id="system-prompt-design"></a>

### KB Chat Prompt: `apps/server/src/prompts/system-prompt.md`

```markdown
You are a knowledge-base assistant for the **{{KB_PROJECT_NAME}}** project.

## Your Knowledge Base

You have been provided with core documentation files from the project's knowledge base.
Use this context to answer questions accurately.

{{CORE_CONTEXT}}

## Tools Available

You have access to the `fetch_kb_file` tool. Use it to retrieve additional markdown files
from the knowledge base repository when you need more detailed information.

**How to use the INDEX:**
- The INDEX file maps topics, keywords, and concepts to specific files
- Before answering a question that requires specific details, check the INDEX
- Call `fetch_kb_file` with the file path to get the content
- You can call the tool multiple times if you need multiple files

## Clarification Rules

If the user's question meets ANY of these criteria, ask a clarifying question FIRST:
- The question is ambiguous or could refer to multiple topics in the INDEX
- You need to know which specific module, feature, or component they're asking about
- The scope is too broad to give a useful answer
- Critical context is missing (e.g., version, environment)

When asking for clarification:
- Be specific about what you need to know
- Suggest the likely options based on the INDEX
- Keep it concise — one question, 2-3 sentences max

## Response Guidelines

- Answer based ONLY on the knowledge base content
- If information is not in the KB, say so explicitly — do not guess or hallucinate
- Format responses in clear Markdown
- Reference specific file names when citing information
- be thorough but concise
```

### Placeholder Values

| Placeholder | Source | Injected At |
|---|---|---|
| `{{KB_PROJECT_NAME}}` | `process.env.KB_PROJECT_NAME` | Server startup |
| `{{CORE_CONTEXT}}` | Concatenated core file contents from `knowledgeBase.getCoreContext()` | Session creation |

### UD Analyst Prompt: `apps/server/src/prompts/ud-system-prompt.md` (Phase 3)

The UD system prompt is significantly longer than the KB chat prompt because it embeds:
- The full UD template structure (injected via `{{UD_TEMPLATE}}`)
- Questioning category guidance (7 categories with example patterns)
- Iterative workflow rules (rounds, approval gate, assumption markers)

**Key sections:**

1. **Role Definition:**
   ```markdown
   You are a **UD Analyst** for the {{KB_PROJECT_NAME}} project.
   You create Understanding Documents through iterative questioning and refinement.
   You never assume. You always verify understanding against the knowledge base.
   ```

2. **Iterative Loop Instructions:**
   ```
   Receive requirement → Explore KB → Ask 3-7 questions → Process answers → Draft UD
   → Collect feedback → Revise → Repeat until approved → Call create_ud_file
   ```

3. **Questioning Categories (guidance, not full question list):**
   | Category | When to Focus | Example Pattern |
   |---|---|---|
   | Scope | Always — first priority | "What is the exact boundary? What should it NOT affect?" |
   | Data/Mapping | "map", "field", "populate" | "Where does the source data come from? Target?" |
   | Business Logic | "when", "if", "condition", "rule" | "What conditions trigger this? Any exceptions?" |
   | Integration | "API", "external", "sync" | "Which external systems? Direction of data flow?" |
   | UI | "screen", "form", "button" | "Which screens affected? New or modification?" |
   | Testing | Always at end | "How to verify? What does success look like?" |
   | Dependencies | New features, data changes | "Any fields/objects to create first?" |

   **Instruction to LLM:** "Select 3-7 questions per round based on requirement type. Never dump all categories. Prioritize by ambiguity — highest uncertainty first."

4. **UD Template (injected):**
   ```markdown
   {{UD_TEMPLATE}}
   ```
   The full template is read from `ud-template.md` and injected here. Includes all section headers, table formats, and placeholder descriptions.

5. **Approval Gate Rules:**
   - Never call `create_ud_file` until user says: "approved", "looks good", "finalize", "LGTM", "go ahead"
   - If ambiguous, ask: "Should I revise further or is this approved?"
   - Mark all unconfirmed items with `⚠️ ASSUMED`
   - Max 3 questioning rounds, then draft with assumptions

**UD Prompt Placeholders:**

| Placeholder | Source | Injected At |
|---|---|---|
| `{{KB_PROJECT_NAME}}` | `process.env.KB_PROJECT_NAME` | Session creation |
| `{{CORE_CONTEXT}}` | `knowledgeBase.getCoreContext()` | Session creation |
| `{{UD_TEMPLATE}}` | Contents of `ud-template.md` file | Prompt assembly (in `loadUDSystemPrompt()`) |

---

## 11. API Contracts <a id="api-contracts"></a>

### POST /api/chat/stream

**Request (Phase 1 — backward compatible):**
```json
{
  "sessionId": "3f8a2c1d-4b5e-6789-abcd-ef0123456789",
  "message": "Tell me more about token refresh"
}
```

**Request (Phase 3 — with mode):**
```json
{
  "sessionId": "3f8a2c1d-4b5e-6789-abcd-ef0123456789",
  "message": "Create UD for user authentication feature",
  "mode": "ud"
}
```

> The `mode` field is optional and defaults to `"chat"` for backward compatibility.
> When `mode === "ud"`, a separate SDK session is created with the UD analyst system prompt.
> The client does NOT send full message history. The SDK session retains context server-side.

**Response:** SSE stream

```
data: {"type":"status","data":"KB loaded, processing..."}

data: {"type":"tool_start","data":"fetch_kb_file: auth-tokens.md"}

data: {"type":"tool_complete","data":"Loaded auth-tokens.md (2.4 KB)"}

data: {"type":"chunk","data":"The token refresh mechanism"}

data: {"type":"chunk","data":" works by..."}

data: {"type":"done","data":""}
```

**Response: SSE stream (UD mode — includes ud_file_ready event)**

```
data: {"type":"status","data":"Processing..."}

data: {"type":"tool_start","data":"Fetching project-config.md..."}

data: {"type":"tool_complete","data":"Loaded project-config.md (1.8 KB)"}

data: {"type":"chunk","data":"Based on the project context, I need clarity on..."}

... (questioning rounds as chunks) ...

data: {"type":"chunk","data":"## Draft UD\n\n| Ticket | AUTH-123 |..."}

... (after user approves) ...

data: {"type":"tool_start","data":"Creating UD file..."}

data: {"type":"ud_file_ready","data":"{\"filename\":\"UD_AUTH-123.md\",\"content\":\"# UD - AUTH-123\\n...full content...\"}"}

data: {"type":"tool_complete","data":"UD file created"}

data: {"type":"chunk","data":"✅ UD created! Click the download link above to save it."}

data: {"type":"done","data":""}
```

### GET /api/chat/status

**Response:**
```json
{
  "ready": true,
  "filesLoaded": ["copilot-instructions.md", "INDEX.md", "README.md"],
  "errors": [],
  "cacheSize": 3
}
```

### Existing Endpoints (Unchanged)

| Endpoint | Status |
|---|---|
| `POST /api/summarize` | ✅ Unchanged |
| `POST /api/summarize/stream` | ✅ Unchanged |
| `GET /api/health` | ✅ Unchanged |

---

## 12. Verification Checklist <a id="verification-checklist"></a>

### Existing Functionality (Must Still Work)

- [ ] `POST /api/summarize/stream` returns file summaries correctly
- [ ] `POST /api/summarize` returns JSON summary correctly
- [ ] `GET /api/health` returns `{ status: "ok" }`
- [ ] Copilot client warm-up succeeds on startup
- [ ] Graceful shutdown (SIGINT/SIGTERM) works

### New Functionality (Phase 1)

- [ ] Server starts and logs "KB loaded: 3 files"
- [ ] `GET /api/chat/status` returns `{ ready: true, filesLoaded: [...] }`
- [ ] Chat UI renders with input area and empty message list
- [ ] Sending a question returns streaming chunks via SSE
- [ ] Assistant messages render as Markdown
- [ ] Questions requiring additional files trigger `tool_start`/`tool_complete` events
- [ ] Tool activity indicator appears in UI during file fetching
- [ ] Multi-turn conversation maintains context (follow-up questions work without resending history)
- [ ] Same `sessionId` reuses existing SDK session (check server logs)
- [ ] Ambiguous questions trigger the AI to ask clarifying questions naturally
- [ ] AI only answers from KB content, admits when info is missing
- [ ] Long conversations don't crash (infinite sessions compaction works)
- [ ] Server works when `KB_REPO_*` is not configured (KB disabled, chat returns error)
- [ ] Partial KB loading works (e.g., only README.md exists, other core files missing)
- [ ] Closing browser tab does not leave dangling event handlers (check for res.write errors)

### Generalization

- [ ] Change `.env` to point at a different KB repo → restart → agent works with new KB
- [ ] Edit `system-prompt.md` → restart → agent uses updated prompt
- [ ] KB_PROJECT_NAME appears in agent responses

### UD Creation Agent (Phase 3)

- [ ] Mode toggle appears in chat header ("KB Chat" / "UD Creator" buttons)
- [ ] Clicking "UD Creator" changes header subtitle to "UD Creation Agent"
- [ ] Switching modes preserves messages in each mode (no loss)
- [ ] UD mode generates a separate `sessionId` (check server logs for composite key)
- [ ] Typing a requirement in UD mode triggers 3-7 clarifying questions (not 30+)
- [ ] Questions are grouped by category with brief context for why they're asked
- [ ] Answering questions leads to a follow-up round or a draft UD
- [ ] Max 3 questioning rounds before LLM produces a draft (with `⚠️ ASSUMED` markers if needed)
- [ ] Draft UD follows the template structure (Summary, Business Rules, Acceptance Criteria, etc.)
- [ ] LLM references actual KB files when populating Affected Components
- [ ] Replying "approved" triggers `create_ud_file` tool execution
- [ ] `ud_file_ready` SSE event is received by frontend with `{ filename, content }` payload
- [ ] Download link appears in the chat area after UD file creation
- [ ] Clicking download link saves a valid `.md` file with correct content
- [ ] KB Chat mode continues to work identically after Phase 3 changes (regression)
- [ ] Requests without `mode` field default to `"chat"` (backward compatibility)
- [ ] Invalid `mode` values are rejected with 400 status
- [ ] Chat session and UD session can coexist (different composite keys in Map)
- [ ] Idle UD sessions are reaped by cleanup (same 30 min TTL)
- [ ] LLM uses KB context during UD creation (fetches relevant KB files)
- [ ] Editing `ud-system-prompt.md` → restart → UD agent uses updated prompt

---

## 13. SDK Verification Notes <a id="sdk-verification-notes"></a>

> These findings were confirmed by fetching the actual type definitions from
> `https://unpkg.com/@github/copilot-sdk@0.1.30/dist/types.d.ts` on March 4, 2026.
> All plan decisions above incorporate these corrections.

| # | Issue | Severity | Finding | Fix Applied |
|---|---|---|---|---|
| 1 | Zod v4 incompatibility | **HIGH** | SDK `ZodSchema` interface requires `.toJSONSchema()` as a method on the schema object. Zod v4 removed this method and replaced it with a standalone `z.toJSONSchema(schema)` function. Using a Zod v4 schema with `defineTool` would throw at runtime. | Use raw JSON schema (`Record<string, unknown>`) — also accepted by the SDK. No Zod dependency. |
| 2 | Multi-turn session model | **HIGH** | `session.send()` accepts only `{ prompt: string, attachments?, mode? }` — it cannot inject conversation history, roles, or prior messages. Sending history via the request body and building a session per-request would lose all context after the first reply. | Server-side session `Map<string, CopilotSession>`. Client sends stable `sessionId` UUID. Sessions persist between HTTP requests. SDK retains conversation context internally. |
| 3 | KB token isolation | **MEDIUM** | `github.ts::getToken()` reads `COPILOT_GITHUB_TOKEN \|\| GH_TOKEN \|\| GITHUB_TOKEN` — no support for `KB_GITHUB_TOKEN`. Modifying `github.ts` is out of scope (zero-changes rule). | `knowledgeBase.ts` implements its own `fetchKBFileContent()` with token order `KB_GITHUB_TOKEN → COPILOT_GITHUB_TOKEN → GITHUB_TOKEN`. |
| 4 | SSE handler leaks | **MEDIUM** | Sessions are reused across HTTP requests. If `session.on()` handlers from request N are not removed, they fire during request N+1 and attempt to write to the already-closed N response object. | `session.on()` returns `() => void` unsubscribe. Store per-request in array; call all on `res.on("close", ...)`. |
| 5 | `onPermissionRequest` required | **LOW** | `SessionConfig.onPermissionRequest: PermissionHandler` has no `?` — it is **required**. Omitting it causes a TypeScript compile error. | `import { approveAll } from "@github/copilot-sdk"` → `onPermissionRequest: approveAll`. |
| 6 | Prompt file path in compiled mode | **LOW** | `fs.readFileSync` with `import.meta.url`-relative path resolves correctly when running via `tsx watch` (source). After `tsc` compile to `dist/`, `.md` files are not copied and the path breaks. | Accepted for Phase 1. Dev uses `tsx watch`. Document copy step for production builds. |

---

## 14. Phase 4 — Production Hardening & Scalability <a id="phase-4"></a>

> **Status:** 📋 Planned  
> **Prerequisite:** Phases 1–3 complete  
> **Goal:** Evolve SDLC-Copilot from a prototype into a production-grade, horizontally scalable multi-user product.

All items below were identified during the March 9, 2026 security & architecture audit. P0/P1 items have been implemented as part of that audit. This section tracks remaining P2/P3 work.

### Already Implemented (March 9, 2026 Audit — P0/P1)

| Item | Status | Files Changed |
|---|---|---|
| API key / Bearer token authentication | ✅ Done | `middleware/auth.ts`, `index.ts` |
| Session ownership binding (userId:sessionId:mode key) | ✅ Done | `chatAgent.ts` |
| Global + per-user session caps with LRU eviction | ✅ Done | `chatAgent.ts` |
| SSRF protection — repo allowlist for summarize endpoint | ✅ Done | `middleware/validate.ts` |
| Centralized input validation (UUID format, max lengths, safe paths) | ✅ Done | `middleware/validate.ts` |
| Body size limit (`express.json({ limit: '100kb' })`) | ✅ Done | `index.ts` |
| Security headers via `helmet` | ✅ Done | `index.ts` |
| Rate limiting — global + streaming-specific (express-rate-limit) | ✅ Done | `middleware/rate-limit.ts`, routes |
| SSE heartbeat keep-alive (configurable, default 20s) | ✅ Done | `routes/chat.ts` |
| Request coalescing for concurrent KB file fetches | ✅ Done | `knowledgeBase.ts` |
| Exponential backoff retry on GitHub API (2 retries, 5xx only) | ✅ Done | `github.ts`, `knowledgeBase.ts` |
| Prompt template in-memory caching (no repeated `readFileSync`) | ✅ Done | `prompts/prompt-loader.ts` |
| Cryptographically secure session ID generation in frontend | ✅ Done | `ChatInterface.tsx` |
| Remove token format leakage from logs | ✅ Done | `copilot.ts` |
| `x-api-key` header support in frontend fetch calls | ✅ Done | `ChatInterface.tsx`, `FileSummarizer.tsx` |
| Unauthenticated `/healthz` probe for load balancers | ✅ Done | `index.ts` |
| CORS hardening (explicit methods + allowedHeaders) | ✅ Done | `index.ts` |

### New Environment Variables Added (March 9, 2026)

```env
# ─── Security ──────────────────────────────────────
# Comma-separated API keys. If unset, auth is disabled (dev mode only).
API_KEYS=key1,key2

# Comma-separated owner/repo pairs the summarize endpoint may access.
# If unset, any repo accessible by GITHUB_TOKEN is allowed (dev mode warning).
ALLOWED_REPOS=myorg/myrepo,myorg/another-repo

# ─── Session Limits ────────────────────────────────
MAX_TOTAL_SESSIONS=500
MAX_SESSIONS_PER_USER=10

# ─── Rate Limiting ─────────────────────────────────
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX=30
RATE_LIMIT_STREAM_MAX=10

# ─── SSE ───────────────────────────────────────────
SSE_HEARTBEAT_MS=20000

# ─── Frontend ──────────────────────────────────────
NEXT_PUBLIC_API_KEY=your_api_key_here
```

---

### Phase 4a — Stateful Session Externalization (P1 Architecture)

**Problem:** Sessions are stored in an in-memory `Map`. This means:
- Sessions are lost on server restart.
- You cannot run multiple server instances behind a load balancer.
- One instance crash = all active user sessions gone.

**Solution path:**

| Step | Action | Effort |
|---|---|---|
| 4a-1 | Add sticky sessions (session affinity) at the load balancer level | Low |
| 4a-2 | Add Redis (`ioredis`) for session metadata storage (lastUsedAt, userId, mode) | Medium |
| 4a-3 | On session miss, reconstruct SDK session from Redis metadata (replay system prompt + tool config) | Medium |
| 4a-4 | Store conversation summaries in Redis for fast multi-instance context recovery | High |

**Architecture target:**
```
[Load Balancer] ──sticky-session──→ [Server Instance 1]
               ──sticky-session──→ [Server Instance 2]
                         ↓                   ↓
                    [Redis Cluster]   ←session metadata→
                    [PostgreSQL]      ←conversation history→
```

---

### Phase 4b — WebSocket Migration (P2 Architecture)

**Problem:** SSE is unidirectional (server → client only).
- Phase 2 "ask-user" bridge requires bidirectional communication.
- SSE has a 6-connection browser limit per domain.
- No reconnection support — page refresh loses stream.

**Solution:** Migrate streaming layer to WebSocket via `socket.io`.

**Changes required:**

| File | Change |
|---|---|
| `apps/server/src/index.ts` | Add `socket.io` server alongside Express HTTP server |
| `apps/server/src/routes/chat.ts` | Replace SSE route with socket event handler (`socket.on("chat:message", ...)`) |
| `apps/web/src/components/ChatInterface.tsx` | Replace `fetch` + SSE `ReadableStream` with `socket.io-client` |
| `packages/shared/src/index.ts` | Add socket event type contracts |

**Benefits over SSE:**
- Bidirectional — enables `ask_user` bridge without a separate REST callback endpoint
- Automatic reconnection with exponential backoff
- Room-based session isolation (each `sessionId` joins its own room)
- Multiplexed over one connection (no browser 6-connection limit)
- Binary data support (future: file attachments)

---

### Phase 4c — Persistence Layer (P2 Architecture)

**Problem:** No database. Chat history, UD documents, and user preferences are lost on each page refresh. No audit trail.

**Solution:** Add PostgreSQL with Prisma ORM.

**Schema design:**

```prisma
model User {
  id        String    @id @default(uuid())
  apiKeyHash String   @unique  // SHA-256 hash of API key
  createdAt DateTime  @default(now())
  sessions  Session[]
  udFiles   UDFile[]
}

model Session {
  id          String   @id @default(uuid())
  userId      String
  mode        String   // "chat" | "ud"
  createdAt   DateTime @default(now())
  lastUsedAt  DateTime @updatedAt
  user        User     @relation(fields: [userId], references: [id])
  messages    Message[]
}

model Message {
  id        String   @id @default(uuid())
  sessionId String
  role      String   // "user" | "assistant"
  content   String
  createdAt DateTime @default(now())
  session   Session  @relation(fields: [sessionId], references: [id])
}

model UDFile {
  id        String   @id @default(uuid())
  userId    String
  filename  String
  content   String   @db.Text
  createdAt DateTime @default(now())
  user      User     @relation(fields: [userId], references: [id])
}
```

**Changes required:**

| File | Change |
|---|---|
| `apps/server/src/db.ts` (new) | Prisma client singleton |
| `apps/server/src/chatAgent.ts` | Persist messages to DB after each turn |
| `apps/server/src/routes/chat.ts` | `GET /api/chat/history/:sessionId` endpoint |
| `apps/server/prisma/schema.prisma` (new) | Schema definition |
| `apps/web/src/components/ChatInterface.tsx` | Load history on session restore |

---

### Phase 4d — Observability Stack (P2 Architecture)

**Problem:** Only `console.log` for monitoring. No structured logging, no metrics, no distributed tracing. Production incidents are impossible to debug.

**Solution:** Three-pillar observability.

#### Logging — `pino`
```typescript
// Replace console.log with structured JSON logger
import pino from "pino";
export const logger = pino({
  level: process.env.LOG_LEVEL || "info",
  // In production: pipe to Loki / CloudWatch / Datadog
});
// Usage:
logger.info({ sessionId, userId, mode }, "Session created");
logger.error({ err, sessionId }, "Session error");
```

#### Metrics — `prom-client` (Prometheus)
Expose `/metrics` endpoint with:
- `http_requests_total` — labelled by route, method, status
- `session_count` — gauge (active sessions)
- `kb_cache_hits_total` / `kb_cache_misses_total`
- `llm_request_duration_seconds` — histogram
- `github_api_requests_total` / `github_api_errors_total`

#### Tracing — OpenTelemetry
```typescript
// Trace each request end-to-end: client → Express → KB fetch → LLM → SSE
import { trace } from "@opentelemetry/api";
const tracer = trace.getTracer("sdlc-copilot");
const span = tracer.startSpan("chat.request");
// ... work ...
span.end();
```

---

### Phase 4e — Multi-Tenancy & RBAC (P2 Architecture)

**Problem:** Single KB repo for all users. No concept of teams, projects, or access control.

**Design:**

| Concept | Description |
|---|---|
| **Tenant** | An organization or project team. Has its own KB repo config. |
| **User** | Belongs to a Tenant. Has a role within that tenant. |
| **Role** | `admin` (manage KB config), `member` (chat + UD), `viewer` (chat only) |
| **KB Project** | Mapped to a specific GitHub repo. Owned by a Tenant. |

**Session key extension:**
```
${tenantId}:${userId}:${sessionId}:${mode}
```

**Environment extension:**
```env
# Multi-tenant KB config (JSON or YAML file path)
KB_CONFIG_FILE=./kb-projects.json
# Format: [{ tenantId, owner, repo, ref, projectName, allowedRoles }]
```

---

### Phase 4f — Containerization & CI/CD (P3)

#### Dockerfiles

**`apps/server/Dockerfile`:**
```dockerfile
FROM node:22-alpine AS builder
WORKDIR /app
COPY package*.json turbo.json ./
COPY apps/server/package.json apps/server/
COPY packages/shared/package.json packages/shared/
RUN npm ci --workspace=apps/server --workspace=packages/shared
COPY packages/shared packages/shared
COPY apps/server apps/server
RUN npm run build --workspace=packages/shared
RUN npm run build --workspace=apps/server
# Copy prompt .md files to dist (readFileSync path fix)
RUN cp apps/server/src/prompts/*.md apps/server/dist/prompts/

FROM node:22-alpine AS runtime
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/apps/server/dist ./dist
COPY --from=builder /app/apps/server/package.json .
COPY --from=builder /app/node_modules ./node_modules
EXPOSE 4000
CMD ["node", "dist/index.js"]
```

**`apps/web/Dockerfile`:**
```dockerfile
FROM node:22-alpine AS builder
WORKDIR /app
COPY package*.json turbo.json ./
COPY apps/web/package.json apps/web/
COPY packages/shared/package.json packages/shared/
RUN npm ci --workspace=apps/web --workspace=packages/shared
COPY packages/shared packages/shared
COPY apps/web apps/web
RUN npm run build --workspace=apps/web

FROM node:22-alpine AS runtime
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/apps/web/.next ./.next
COPY --from=builder /app/apps/web/public ./public
COPY --from=builder /app/apps/web/package.json .
COPY --from=builder /app/node_modules ./node_modules
EXPOSE 3000
CMD ["node_modules/.bin/next", "start"]
```

**`docker-compose.yml` (local dev):**
```yaml
services:
  server:
    build: { context: ., dockerfile: apps/server/Dockerfile }
    ports: ["4000:4000"]
    env_file: .env
    depends_on: [redis]
  web:
    build: { context: ., dockerfile: apps/web/Dockerfile }
    ports: ["3000:3000"]
    env_file: .env
  redis:
    image: redis:7-alpine
    ports: ["6379:6379"]
```

#### GitHub Actions CI Pipeline (`.github/workflows/ci.yml`)

```yaml
on: [push, pull_request]
jobs:
  ci:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 22, cache: npm }
      - run: npm ci
      - run: npx tsc --noEmit --project apps/server/tsconfig.json
      - run: npx tsc --noEmit --project apps/web/tsconfig.json
      - run: npm test --workspaces --if-present
      - run: docker build -f apps/server/Dockerfile .
      - run: docker build -f apps/web/Dockerfile .
```

---

### Phase 4g — Test Suite (P3)

**Zero tests currently exist.** Minimum viable test coverage:

#### Unit Tests (Vitest)

| Module | Tests |
|---|---|
| `middleware/validate.ts` | UUID validation, max length enforcement, path traversal rejection, repo allowlist |
| `middleware/auth.ts` | Valid/invalid API keys, timing-safe comparison, dev mode bypass |
| `knowledgeBase.ts` | Path traversal guard, extension whitelist, LRU eviction, request coalescing |
| `prompts/prompt-loader.ts` | Placeholder replacement, template caching, fallback on missing file |
| `chatAgent.ts` | Session cap enforcement, userId binding, per-user limit, LRU eviction |

#### Integration Tests (Vitest + Supertest)

| Route | Tests |
|---|---|
| `POST /api/chat/stream` | 400 on invalid body, 401 on missing auth, 429 on rate limit, 400 on non-UUID sessionId |
| `POST /api/summarize` | 400 on missing fields, 400 on disallowed repo, path injection rejection |
| `GET /api/chat/status` | Returns KB status structure |
| `GET /healthz` | Returns 200 without auth |

#### E2E Tests (Playwright)

| Flow | Tests |
|---|---|
| KB Chat | Send message → receive streaming response → tool activity indicator shown |
| UD Creator | Switch mode, send requirement, receive questions, approve, download UD file |
| Auth | Request with missing API key returns error message |

---

### Phase 4 Priority Summary

| Priority | Phase | Item | Effort |
|---|---|---|---|
| **P1** | 4a | Sticky sessions + Redis externalization | High |
| **P2** | 4b | WebSocket migration (`socket.io`) | High |
| **P2** | 4c | PostgreSQL persistence (Prisma) | High |
| **P2** | 4d | Observability (pino + Prometheus + OTel) | Medium |
| **P2** | 4e | Multi-tenancy + RBAC | High |
| **P3** | 4f | Dockerfiles + docker-compose + CI/CD | Medium |
| **P3** | 4g | Unit + integration + E2E test suite | High |

### Phase 4 Dependency Order

```
Phase 4a (Redis sessions)  ─→ Phase 4b (WebSocket)  ─→ Phase 4e (multi-tenancy)
Phase 4c (PostgreSQL)      ─→ Phase 4e (RBAC)
Phase 4d (Observability)   ── independent (add anytime)
Phase 4f (Docker/CI)       ── independent (add anytime)
Phase 4g (Tests)           ── independent (add unit tests now, E2E after 4b)
```
